@echo off
rem Opens the gradebook dashboard in your browser. It runs only on this computer.
rem Leave this window open while you use the dashboard; closing it stops the dashboard.
rem The first time, it asks before installing Python or the packages the dashboard needs.
call "%~dp0tool\launch.bat" dashboard
