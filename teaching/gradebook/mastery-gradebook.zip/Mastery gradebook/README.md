# Mastery gradebook

A gradebook for a course graded by standards. It reads the class list, the Gradescope exports of your assessments and, if you have one, a Canvas gradebook export, and shows where each student stands on each standard. It is rebuilt from the files in this folder every time it is opened or reloaded, so putting a fresh download in `exports/` is the whole update. Nothing leaves your computer.

## Starting

1. Unzip the folder anywhere, for example in OneDrive.
2. Double-click `Open Dashboard.command` on a Mac or `Open Dashboard.bat` on Windows. A terminal window opens.
   - If the computer has no Python 3.11 or later, the window offers to install it. On a Mac it downloads the python.org installer and opens it. On Windows it installs Python with winget, or opens python.org if winget is missing. When the installation is done, open the launcher again.
   - If Streamlit or openpyxl is missing, the window shows the command that installs them for your user account and asks before running it.
   - On a Mac that refuses to open the launcher because it is from an unidentified developer, right-click it, choose Open, and confirm. This is needed only once.
3. The dashboard opens in your browser on its setup page. Fill in the course, how a standard appears in a Gradescope question title, and your mark levels, then press Save. Everything there can be changed later on the Setup tab.
4. Put the registrar's class list and the Gradescope exports in `exports/`, then press Reload in the sidebar.

Leave the terminal window open while you use the dashboard, and close it to stop the dashboard.

## Mark levels

List your levels from best to worst, at most six. For each give
- a short name, which the tables show, such as M or E,
- a label, such as Meets or Exemplary,
- the score you enter in Gradescope for it, with at most 4 decimal places, and different for every level,
- whether it counts as mastered (these levels come first), and
- whether it can be revised. A revisable level is listed on the Revisions tab until a later mark replaces it.

The setup page shows the scores found in any Gradescope export already in `exports/`, and warns about a score that matches no level. Each standard should be one Gradescope question whose title contains the standard, such as "1: S01 (1.0 pts)". A standard's status is its best level over all sittings, so a mastered standard is never lost.

## The folder

| Where | What it holds |
|---|---|
| `Open Dashboard`, `Build Excel` | The launchers to double-click, `.command` on the Mac and `.bat` on Windows. `Build Excel` writes the workbook without opening the dashboard. |
| `course.toml` | The settings, written by the setup page. Groups of standards, sitting labels, the Canvas homework settings, the columns you fill in by hand and the kinds of office-hour attempt are edited in this file directly. |
| `exports/` | Everything you download: the class list (a CSV with LastName, FirstName and Email), the Gradescope exports and the Canvas gradebook export. Replace a file with a new download whenever marks change. A repeated download such as `... (1).xlsx` can stay beside the old one, since the newer file is used. |
| `records/` | What the tool keeps: your entries by hand, the office-hour attempts, every mark that changed between two downloads, and the marks at the last download. |
| `output/` | What the tool writes: the Excel workbook, the Canvas upload file and a read-only phone page. |
| `tool/` | The code. |

## Using it

- **Entries by hand.** Type them on the Manual entries tab. Each cell is saved as soon as you leave it.
- **Office hours.** Attempts outside the Gradescope assessments are entered on the Office hours tab and count as one more sitting. To limit how many each student may make, add a kind of attempt to `course.toml`, for example

  ```toml
  [[office_hours.kind]]
  name = "Before Assessment 3"
  per_student = 1
  before = 2026-11-13
  ```

  An attempt at a standard that the previous assessment gave a revisable level is counted as a revision of that mark, not toward `per_student`.
- **Canvas.** If Canvas has one assignment per standard, named exactly like the standard (S01, S02, ...), the "Write Canvas upload file" button writes a file that sets each to complete or incomplete. Import it in the Canvas gradebook.
- **Homework.** From a Canvas gradebook export in `exports/`, the homework score is the points earned on the graded assignments whose names start with "Homework", over 95% of their points possible, capped at 100%. Change the pattern and the 95% under `[canvas]` in `course.toml`.
- **Base grade.** The Setup tab has a checklist, such as "A needs 9 standards mastered and 90% homework". The base grade stays blank until every planned standard has been assessed.
- **After changing the code.** Run `python3 tool/selftest.py`. It checks everything on a made-up course in a temporary folder.
- **Another course.** Run `python3 tool/make_clean_copy.py <new folder>` to make a copy like this one, with no student data.

The folder holds student records once you use it, so keep it somewhere your institution allows for student data.
