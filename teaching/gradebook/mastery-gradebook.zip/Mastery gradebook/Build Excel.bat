@echo off
rem Rebuilds the Excel gradebook in output\ from the files in this folder.
rem The first time, it asks before installing Python or the packages the build needs.
call "%~dp0tool\launch.bat" build
