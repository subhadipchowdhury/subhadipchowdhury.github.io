#!/bin/bash
# Rebuilds the Excel gradebook in output/ from the files in this folder.
# The first time, it asks before installing Python or the packages the build needs.
exec bash "$(dirname "$0")/tool/launch.sh" build
