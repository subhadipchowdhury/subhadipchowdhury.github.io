#!/bin/bash
# Opens the gradebook dashboard in your browser. It runs only on this computer.
# Leave this window open while you use the dashboard; closing it stops the dashboard.
# The first time, it asks before installing Python or the packages the dashboard needs.
exec bash "$(dirname "$0")/tool/launch.sh" dashboard
