@echo off
rem Finds a Python 3.11 or later, checks the packages the gradebook needs, and runs it.
rem The .bat launchers in the course folder call it:  tool\launch.bat dashboard  (or build).
rem If no suitable Python is found, it offers to install one with winget, or opens python.org.
setlocal
cd /d "%~dp0.."
set PYTHONDONTWRITEBYTECODE=1
set "PY="
rem The py launcher comes with the python.org installer. "python" on the PATH can be the Microsoft Store's
rem placeholder, which is not Python, so it is tried second and only counts if it runs.
py -3 -c "import sys; sys.exit(sys.version_info < (3, 11))" >nul 2>nul && set "PY=py -3"
if not defined PY python -c "import sys; sys.exit(sys.version_info < (3, 11))" >nul 2>nul && set "PY=python"
if defined PY goto run

echo The gradebook needs Python 3.11 or later, and this computer does not have it.
echo.
where winget >nul 2>nul
if errorlevel 1 goto manual
choice /m "Install Python 3.13 from python.org now, with winget"
if errorlevel 2 goto manual
winget install -e --id Python.Python.3.13 --scope user --accept-package-agreements --accept-source-agreements
echo.
echo When the installation has finished, close this window and open the launcher again.
pause
exit /b 1

:manual
echo Install Python from https://www.python.org/downloads/ and open this launcher again.
start "" "https://www.python.org/downloads/windows/"
pause
exit /b 1

:run
if /i "%~1"=="dashboard" goto dashboard
if /i "%~1"=="build" goto build
echo Usage: tool\launch.bat dashboard^|build
exit /b 2

:dashboard
%PY% tool\check_setup.py --dashboard
if errorlevel 1 (
    pause
    exit /b 1
)
rem Colours and the toolbar are set in .streamlit\config.toml; the two privacy settings are repeated here.
%PY% -m streamlit run tool\dashboard.py --server.address localhost --browser.gatherUsageStats false
pause
exit /b 0

:build
%PY% tool\check_setup.py
if errorlevel 1 (
    pause
    exit /b 1
)
%PY% tool\build.py
pause
exit /b 0
