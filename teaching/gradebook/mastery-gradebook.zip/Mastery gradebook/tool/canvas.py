"""The Canvas gradebook export, and the upload file that sends standards back to Canvas."""

from __future__ import annotations

import csv
import datetime as dt
import re
from dataclasses import dataclass, field
from pathlib import Path

from files import UPLOAD_FILE, output_dir, read_rows, to_float

ID_COLUMNS = ["Student", "ID", "SIS User ID", "SIS Login ID", "Section"]
ASSIGNMENT = re.compile(r"^(.*\S)\s+\((\d+)\)$")   # "S01 (922227)"


@dataclass
class CanvasExport:
    path: Path
    modified: dt.datetime
    ids: dict = field(default_factory=dict)          # email -> the five Canvas identifier values
    standards: dict = field(default_factory=dict)    # standard -> its column header, e.g. "S01 (922227)"
    homework: list = field(default_factory=list)     # (column header, points possible, graded?)


def read_canvas(path: Path, cfg, students, assessed):
    """Read a Canvas export. Returns the export, the homework score of each student as a fraction
    ({email: score}), and warnings. `assessed` lists the standards assessed so far."""
    rows = read_rows(path)
    header = [str(h or "") for h in rows[0]]
    col = {h: i for i, h in enumerate(header)}
    cv = CanvasExport(path, dt.datetime.fromtimestamp(path.stat().st_mtime))
    points = next((r for r in rows[1:] if str(r[0] or "").strip() == "Points Possible"), None)
    people = [r for r in rows[1:] if str(r[0] or "").strip() not in ("", "Points Possible", "Student, Test")]

    pattern = re.compile(cfg["gradescope"].get("standard_pattern", r"S\d+"))
    hw_pattern = re.compile(cfg.get("canvas", {}).get("homework_pattern", r"^Homework"))
    for h in header:
        m = ASSIGNMENT.match(h)
        if not m:
            continue
        name = m.group(1)
        if pattern.fullmatch(name):
            cv.standards[name] = h
        elif hw_pattern.search(name):
            possible = to_float(points[col[h]]) if points else None
            graded = any(to_float(r[col[h]]) is not None for r in people)
            cv.homework.append((h, possible or 0.0, graded))

    by_login = {s.email.split("@")[0]: s for s in students}
    by_sid = {s.sid: s for s in students if s.sid}
    by_name = {f"{s.last}, {s.first}".lower(): s for s in students}
    divisor = float(cfg.get("canvas", {}).get("homework_divisor", 0.95))
    homework, unmatched, warnings = {}, [], []
    for r in people:
        login = str(r[col["SIS Login ID"]] or "").strip().lower()
        sid = str(r[col["SIS User ID"]] or "").strip()
        s = by_login.get(login) or by_sid.get(sid) or by_name.get(str(r[0]).strip().lower())
        if s is None:
            unmatched.append(str(r[0]).strip())
            continue
        cv.ids[s.email] = {c: str(r[col[c]] or "") for c in ID_COLUMNS if c in col}
        earned = possible = 0.0
        for h, pts, graded in cv.homework:
            value = str(r[col[h]] or "").strip()
            if not graded or value.upper() == "EX":
                continue
            earned += to_float(value) or 0.0
            possible += pts
        homework[s.email] = min(1.0, earned / (divisor * possible)) if possible else None

    if unmatched:
        warnings.append(f"Canvas: not on the roster, so left out: {'; '.join(unmatched)}.")
    missing = [s.name for s in students if s.email not in cv.ids]
    if missing:
        warnings.append("Canvas: on the roster but not in the Canvas export: " + ", ".join(missing) + ".")
    no_column = [std for std in assessed if std not in cv.standards]
    if no_column:
        warnings.append("Canvas: no assignment for " + ", ".join(no_column) + " in the Canvas export, so the "
                        "upload file leaves them out. Create them in Canvas, then download a new export.")
    return cv, homework, warnings


def write_upload(gb, path: Path | None = None):
    """A Canvas gradebook import file that sets each assessed standard to complete (1) or incomplete (0).
    Canvas uploads full credit as complete and zero as incomplete. Only columns that already exist in the
    Canvas export and are named exactly like a standard are filled. Returns the path and the standards."""
    if gb.canvas is None:
        raise ValueError("There is no Canvas gradebook export in exports/.")
    stds = [std for std in gb.standards if gb.first_assessed(std) and std in gb.canvas.standards]
    path = Path(path) if path else output_dir(gb.folder) / UPLOAD_FILE
    with open(path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(ID_COLUMNS + [gb.canvas.standards[std] for std in stds])
        for s in gb.students:
            ids = gb.canvas.ids.get(s.email)
            if ids is None:
                continue
            writer.writerow([ids.get(c, "") for c in ID_COLUMNS]
                            + [1 if gb.levels.mastered(gb.mark(s.email, std)) else 0 for std in stds])
    return path, stds
