"""Local dashboard for the mastery gradebook.

Start it with the launcher in the course folder ("Open Dashboard.command" on the Mac,
"Open Dashboard.bat" on Windows), or with
    python -m streamlit run tool/dashboard.py
from the course folder, whose .streamlit/config.toml keeps the page on this computer.
It reads the course folder above tool/, or the folder in the GRADEBOOK_FOLDER variable.
"""

from __future__ import annotations

import datetime as dt
import os
import re
import subprocess
import sys
from pathlib import Path

import altair as alt
import pandas as pd
import streamlit as st

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.dont_write_bytecode = True  # keep tool/__pycache__ out of the synced folder

import engine  # noqa: E402
import levels  # noqa: E402
from config import config_exists, default_config  # noqa: E402
from engine import HELD, change_text, day  # noqa: E402
from excel_writer import write_workbook  # noqa: E402
from phone_view import phone_path, write_phone_view  # noqa: E402
import style  # noqa: E402
from style import ACCENT, GRADE_TINT, INK  # noqa: E402

FOLDER = Path(os.environ.get("GRADEBOOK_FOLDER") or HERE.parent).resolve()

st.set_page_config(page_title="Mastery gradebook", page_icon=":material/grading:", layout="wide")


# ----------------------------------------------------------------------------- loading

def folder_signature(folder: Path):
    """Names, sizes and modification times of the files the gradebook is built from, so that
    replacing a download reloads the page, while the tool's own writes do not."""
    return tuple((str(p), p.stat().st_size, p.stat().st_mtime_ns) for p in engine.source_files(folder))


@st.cache_resource(show_spinner="Reading the folder")
def load_gradebook(folder: str, signature):
    return engine.load(Path(folder))


def missing(v):
    return v is None or (not isinstance(v, (bool, str)) and pd.isna(v))


def open_path(path):
    """Open a file or folder in the program the computer uses for it."""
    if sys.platform == "darwin":
        subprocess.Popen(["open", str(path)])
    elif os.name == "nt":
        os.startfile(str(path))  # noqa: S606
    else:
        subprocess.Popen(["xdg-open", str(path)])


def mode():
    theme = getattr(st.context, "theme", None)
    return "dark" if theme is not None and getattr(theme, "type", None) == "dark" else "light"


def surface():
    """The page colour, for the gaps between chart marks."""
    return st.get_option(f"theme.{mode()}.backgroundColor") or ("#0e1117" if mode() == "dark" else "#ffffff")


def accent():
    return ACCENT[mode()]


def style_marks(value):
    """The style of a table cell showing a mark, as levels.display shows it. Uses the page's gradebook."""
    bg, fg, weight = style.cell(gb.levels, HELD if value == gb.levels.held else value)
    return f"background-color: {bg}; color: {fg}; font-weight: {weight}; text-align: center"


def style_grade(value):
    if value not in GRADE_TINT:
        return ""
    return f"background-color: {GRADE_TINT[value]}; color: {INK}; font-weight: 600"


def fmt_manual(gb, email, name):
    v = gb.manual_value(email, name)
    if v is None:
        return ""
    kind = gb.manual_type(name)
    if kind == "percent":
        return f"{v:.0%}"
    if kind == "yes/no":
        return "yes" if v else ""
    return str(v)


def manual_text(gb, name, v):
    """An edited cell as the text manual.csv keeps."""
    kind = gb.manual_type(name)
    if missing(v):
        return ""
    if kind == "yes/no":
        return "yes" if v else ""
    if kind == "integer":
        return str(int(v))
    if kind == "percent":
        return f"{float(v):g}"
    return str(v)


# ----------------------------------------------------------------------------- tables

def students_frame(gb):
    rows = []
    for s in gb.students:
        hw = gb.homework_score(s.email)
        row = {"Last Name": s.last, "First Name": s.first, "Email": s.email,
               "Base grade": gb.base_grade(s.email) or "", f"Standards {gb.levels.at}": gb.count_m(s.email),
               "Homework": None if hw is None else round(100 * hw, 1)}
        for std in gb.standards:
            row[std] = gb.mark(s.email, std) or ""
        for name in gb.manual_columns():
            row[name] = fmt_manual(gb, s.email, name)
        for k, sit in enumerate(gb.sittings):
            row[sit.label] = ", ".join(gb.mastered_at(s.email, k))
        rows.append(row)
    return pd.DataFrame(rows)


def sitting_frame(gb, k):
    sit = gb.sittings[k]
    rows = []
    for s in gb.students:
        row = {"Last Name": s.last, "First Name": s.first, "Status": sit.status.get(s.email, "Not in export")}
        rs = []
        for std in sit.standards:
            m = gb.sitting_mark(s.email, k, std)
            row[std] = gb.levels.display(m)
            if gb.levels.revisable(m):
                rs.append(std)
        row["Mastered here"] = ", ".join(gb.mastered_at(s.email, k))
        if gb.levels.revisable_names:
            row[revise_here(gb)] = ", ".join(rs)
        rows.append(row)
    return pd.DataFrame(rows)


def revise_here(gb):
    """ "R here", or "To revise here"."""
    word = gb.levels.to_revise
    return f"{word[0].upper()}{word[1:]} here"


def manual_frame(gb):
    rows = []
    for s in gb.students:
        row = {"Last Name": s.last, "First Name": s.first, "Email": s.email}
        for name in gb.manual_columns():
            v = gb.manual_value(s.email, name)
            kind = gb.manual_type(name)
            if kind == "percent":
                row[name] = float("nan") if v is None else round(v * 100, 1)
            elif kind == "integer":
                row[name] = float("nan") if v is None else float(v)
            elif kind == "yes/no":
                row[name] = bool(v)
            else:
                row[name] = "" if v is None else str(v)
        rows.append(row)
    return pd.DataFrame(rows)


def standards_frame(gb, through=None):
    rows = []
    for std in gb.standards:
        counts = gb.standard_counts(std, through)
        for j, status in enumerate(gb.levels.statuses):
            rows.append({"Standard": std, "Description": gb.describe(std) or std,
                         "Status": gb.levels.status_label(status),
                         "Students": counts[status], "order": j})
    return pd.DataFrame(rows)


def by_sitting_frame(gb):
    rows = []
    for k, sit in enumerate(gb.sittings):
        s = gb.summary(through=k)
        rows.append({"Sitting": sit.label, "Date": sit.date, f"Median {gb.levels.at}": s["median"],
                     f"Mean {gb.levels.at}": round(s["mean"], 2), "Lower quartile": s["q1"], "Upper quartile": s["q3"]})
    return pd.DataFrame(rows)


def new_m_frame(gb):
    """One row per sitting with the students who reached mastery on each standard there, then the total."""
    rows, total = gb.new_m_table()
    out = [{"Sitting": sit.label, **counts} for sit, counts in rows] + [{"Sitting": "Total", **total}]
    df = pd.DataFrame(out, columns=["Sitting"] + gb.standards)
    for std in gb.standards:
        df[std] = df[std].astype("Int64")  # whole numbers, with a blank where a standard was not on a sitting
    return df


def office_frame(gb):
    """The rows of office_hours.csv, newest first. The index is the row's position in the file."""
    rows = []
    fixes = {a.row: gb.revises(a) for a in gb.office}
    for i, r in enumerate(gb.office_rows):
        rows.append({"Date": engine.to_date(r.get("Date")),
                     "Student": f"{r.get('First Name') or ''} {r.get('Last Name') or ''}".strip(),
                     "Email": r.get("Email") or "", "Standard": r.get("Standard") or "", "Mark": r.get("Mark") or "",
                     "Kind": r.get("Kind") or "",
                     "Counts as": f"Fixes {fixes[i]} R" if fixes.get(i) else ("Retake" if i in fixes else ""),
                     "Entered": r.get("Entered") or ""})
    order = sorted(range(len(rows)), key=lambda i: (rows[i]["Date"] or dt.date.min, i), reverse=True)
    return pd.DataFrame([rows[i] for i in order], index=order,
                        columns=["Date", "Student", "Email", "Standard", "Mark", "Kind", "Counts as", "Entered"])


def changes_frame(rows):
    return pd.DataFrame([{"Export downloaded": r["Export downloaded"], "Sitting": r["Sitting"],
                          "Student": r["Student"], "Standard": r["Standard"], "Change": change_text(r)}
                         for r in reversed(rows)])


# ----------------------------------------------------------------------------- charts

def standards_chart(gb):
    df = standards_frame(gb)
    labels = [gb.levels.status_label(s) for s in gb.levels.statuses]
    colours = [style.status_colour(gb.levels, s) for s in gb.levels.statuses]
    return (
        alt.Chart(df)
        .mark_bar(size=18, stroke=surface(), strokeWidth=2)
        .encode(
            y=alt.Y("Standard:N", sort=gb.standards, title=None),
            x=alt.X("Students:Q", stack="zero", title="Students",
                    scale=alt.Scale(domain=[0, len(gb.students)]), axis=alt.Axis(tickMinStep=1)),
            color=alt.Color("Status:N", scale=alt.Scale(domain=labels, range=colours),
                            legend=alt.Legend(orient="top", title=None)),
            order=alt.Order("order:Q"),
            tooltip=["Standard", "Description", "Status", "Students"],
        )
        .properties(height=alt.Step(30))  # a fixed pixel height would also have to hold the legend and axis
    )


def median_chart(gb):
    df = by_sitting_frame(gb)
    top = max(gb.planned, len(gb.standards), 1)
    med, mean = f"Median {gb.levels.at}", f"Mean {gb.levels.at}"
    base = alt.Chart(df).encode(x=alt.X("Sitting:N", sort=list(df["Sitting"]), title=None, axis=alt.Axis(labelAngle=0)))
    band = base.mark_area(color=accent(), opacity=0.1).encode(
        y=alt.Y("Lower quartile:Q", scale=alt.Scale(domain=[0, top]), title=f"Standards {gb.levels.at}"),
        y2="Upper quartile:Q")
    line = base.mark_line(color=accent(), strokeWidth=2).encode(y=f"{med}:Q")
    dots = base.mark_point(color=accent(), filled=True, size=90, stroke=surface(), strokeWidth=2, opacity=1).encode(
        y=f"{med}:Q",
        tooltip=["Sitting", alt.Tooltip("Date:T", format="%b %d"), med, mean,
                 "Lower quartile", "Upper quartile"])
    return (band + line + dots).properties(height=260)


def histogram(gb):
    top = max(gb.planned, len(gb.standards))
    counts = [gb.count_m(s.email) for s in gb.students]
    col = f"Standards {gb.levels.at}"
    df = pd.DataFrame({col: list(range(top + 1)),
                       "Students": [counts.count(n) for n in range(top + 1)]})
    return (
        alt.Chart(df)
        .mark_bar(color=accent(), size=22, cornerRadiusTopLeft=4, cornerRadiusTopRight=4)
        .encode(x=alt.X(f"{col}:O", axis=alt.Axis(labelAngle=0)),
                y=alt.Y("Students:Q", axis=alt.Axis(tickMinStep=1)),
                tooltip=[col, "Students"])
        .properties(height=260)
    )


# ----------------------------------------------------------------------------- student card

@st.dialog("Student record", width="large")
def student_card(gb, email):
    s = next(x for x in gb.students if x.email == email)
    st.subheader(s.name)
    st.caption(email)
    hw = gb.homework_score(email)
    c = st.columns(4)
    c[0].metric(f"Standards {gb.levels.at}", f"{gb.count_m(email)} of {gb.planned}" if gb.planned else gb.count_m(email))
    c[1].metric("Homework", "–" if hw is None else f"{hw:.0%}")
    c[2].metric(gb.levels.pending, sum(1 for std in gb.standards if gb.levels.revisable(gb.mark(email, std))))
    c[3].metric("Base grade", gb.base_grade(email) or "–")

    st.markdown("**By standard**")
    for std in gb.standards:
        steps = []
        for k, sit in enumerate(gb.sittings):
            if std not in sit.standards or gb.sitting_mark(email, k, std) == HELD:
                continue
            m = sit.marks.get(email, {}).get(std)
            if m:
                steps.append(f":{style.badge(gb.levels, m)}-background[{sit.label} {m}]")
            elif sit.office:
                continue  # office hours list only the standards a student attempted there
            elif sit.status.get(email, "") != "Graded":
                steps.append(f":gray-background[{sit.label} absent]")
            else:
                steps.append(f":gray-background[{sit.label} not attempted]")
        st.markdown(f"**{std}** &nbsp; " + (" → ".join(steps) if steps else ":gray-background[not assessed yet]"))

    notes = [f"**{name}** {fmt_manual(gb, email, name)}" for name in gb.manual_columns() if fmt_manual(gb, email, name)]
    st.markdown("**Entered by hand**  \n" + ("  \n".join(notes) if notes else "Nothing yet."))
    mine = [r for r in gb.changes if r["Email"] == email]
    if mine:
        st.markdown("**Changes recorded**")
        st.dataframe(changes_frame(mine).drop(columns=["Student"]), hide_index=True)


# ----------------------------------------------------------------------------- setup

LEVEL_COLUMNS = ["Name", "Label", "Gradescope score", "Mastered", "Revisable"]


def levels_frame(rows):
    return pd.DataFrame([{"Name": r.get("name", ""), "Label": r.get("label", ""), "Gradescope score": r.get("score"),
                          "Mastered": bool(r.get("mastered")), "Revisable": bool(r.get("revisable"))} for r in rows],
                        columns=LEVEL_COLUMNS)


def levels_from_frame(df):
    """The edited table as level dicts, best first, leaving out rows with no name."""
    rows = []
    for _, r in df.iterrows():
        name = "" if missing(r["Name"]) else str(r["Name"]).strip()
        if not name:
            continue
        rows.append({"name": name, "label": "" if missing(r["Label"]) else str(r["Label"]).strip() or name,
                     "score": None if missing(r["Gradescope score"]) else float(r["Gradescope score"]),
                     "mastered": bool(r["Mastered"]) if not missing(r["Mastered"]) else False,
                     "revisable": bool(r["Revisable"]) if not missing(r["Revisable"]) else False})
    return rows


def levels_editor(rows, key):
    """The table of mark levels. Returns the levels as edited."""
    df = st.data_editor(levels_frame(rows), num_rows="dynamic", hide_index=True, key=key,
                        column_config={
                            "Name": st.column_config.TextColumn(
                                help="The short name the tables show, such as M or E. At most 12 characters."),
                            "Label": st.column_config.TextColumn(help="The full name, such as Meets or Exemplary."),
                            "Gradescope score": st.column_config.NumberColumn(
                                format="%.4f", help="The score you give in Gradescope for this level, with at "
                                                    "most 4 decimal places."),
                            "Mastered": st.column_config.CheckboxColumn(
                                help="The standard counts as mastered at this level. These levels come first."),
                            "Revisable": st.column_config.CheckboxColumn(
                                help="Listed on the Revisions tab until a later mark replaces it, as R is."),
                        })
    st.caption(f"List the levels from best to worst, at most {levels.MAX_LEVELS}. The mastered levels come first. "
               "A standard's status is its best level over all sittings. To add a level, use the empty row at "
               "the bottom; to remove one, select its row and delete it.")
    return levels_from_frame(df)


def exports_preview(pattern, rows):
    """What the pattern and the levels find in the Gradescope exports already in the folder."""
    found, scores = engine.scan_exports(FOLDER, pattern)
    if not found:
        st.caption("No Gradescope export is in exports/ yet. Once one is, this page shows the standards and the "
                   "scores it holds, so you can check these settings against it.")
        return
    for name, stds, missed in found:
        line = f"**{name}**: " + (", ".join(stds) if stds else "no standards found")
        if missed:
            line += ". No standard in " + "; ".join(f"“{m}”" for m in missed)
        st.markdown(line)
    known = [r["score"] for r in rows if r.get("score") is not None]
    odd = [x for x in scores if not any(abs(x - k) < levels.TOLERANCE for k in known)]
    st.markdown("Scores in these exports: " + ", ".join(f"{x:g}" for x in scores) + ".")
    if odd:
        st.warning("No level has the score " + ", ".join(f"{x:g}" for x in odd) + ". These marks would be read as "
                   "not attempted.")


def first_run():
    """The page shown while the folder has no course.toml. Saving writes it."""
    st.title("Set up the gradebook")
    st.markdown("This folder has no settings yet. Fill in the course and the mark levels you use in Gradescope, "
                "then press Save. Everything here can be changed later on the Setup tab. Put the registrar's "
                "class list and the Gradescope exports in exports/ whenever you have them.")
    a, b = st.columns(2)
    title = a.text_input("Course title", placeholder="MATH 10000 Course title")
    term = b.text_input("Term", placeholder="Autumn 2026")
    planned = a.number_input("Standards planned for the term", min_value=0, step=1, value=0,
                             help="The base grade stays blank until this many standards have been assessed.")
    output = b.text_input("Workbook file name", value="Gradebook.xlsx")

    st.subheader("Standards in Gradescope")
    pattern = st.text_input("How a standard appears in a question title", r"S\d+",
                            help="A regular expression. S\\d+ finds S01 in “1: S01 (1.0 pts)”, and LT\\d+ finds "
                                 "LT3 in “3: LT3 (1.0 pts)”.")
    st.subheader("Mark levels")
    rows = levels_editor(levels.LEGACY, "first_levels")
    exports_preview(pattern, rows)

    if st.button("Save", type="primary", icon=":material/save:"):
        trouble = levels.problems(rows)
        try:
            re.compile(pattern)
        except re.error:
            trouble.append("The pattern for standards is not a valid regular expression.")
        if trouble:
            st.error(" ".join(trouble))
            return
        cfg = default_config()
        cfg["course"].update(title=title.strip() or "Course", term=term.strip(), planned_standards=int(planned),
                             output=output.strip() or "Gradebook.xlsx")
        cfg["gradescope"]["standard_pattern"] = pattern
        cfg["level"] = rows
        cfg["office_hours"] = {"label": "OH"}  # on, with no kinds until some are added to course.toml
        engine.save_config(FOLDER, cfg)
        st.cache_resource.clear()
        st.rerun()


# ----------------------------------------------------------------------------- page

if not config_exists(FOLDER):
    first_run()
    st.stop()

gb = load_gradebook(str(FOLDER), folder_signature(FOLDER))
gb.manual = engine.read_manual(FOLDER)  # read on every run, so saved entries show at once
workbook = gb.workbook_path
# Every save reruns the page, either through a reload or through the line above, so the phone page is
# brought up to date here. It is written only when its content has changed.
phone_error = None
if gb.students:
    try:
        write_phone_view(gb)
    except OSError as exc:
        phone_error = exc

with st.sidebar:
    st.subheader("Gradebook")
    st.caption(f"Folder: {FOLDER.name}")
    if st.button("Reload folder", type="primary", icon=":material/refresh:", width="stretch"):
        st.cache_resource.clear()
        st.rerun()
    if st.button("Write Excel gradebook", icon=":material/table_view:", width="stretch"):
        try:
            write_workbook(gb)
            st.success(f"Wrote output/{workbook.name}")
        except PermissionError:
            st.error("The workbook is open in Excel. Close it and try again.")
    if st.button("Open workbook", icon=":material/open_in_new:", width="stretch", disabled=not workbook.exists()):
        open_path(workbook)
    if st.button("Write Canvas upload file", icon=":material/upload_file:", width="stretch",
                 disabled=gb.canvas is None,
                 help="Needs a Canvas gradebook export in exports/." if gb.canvas is None else None):
        path, stds = engine.write_canvas_upload(gb)
        if stds:
            st.success(f"Wrote output/{path.name} with {', '.join(stds)}, 1 for complete and 0 for incomplete. "
                       "In the Canvas gradebook, choose Import and upload this file. Canvas shows the changes "
                       "before it applies them.")
        else:
            st.warning("No assessed standard has an assignment in the Canvas export, so the file has no grades.")
    if st.button("Open folder", icon=":material/folder_open:", width="stretch"):
        open_path(FOLDER)
    st.caption(f"Read {gb.loaded_at:%H:%M:%S}. Put new downloads in exports/, then press Reload.")
    if phone_error:
        st.warning(f"Could not write the phone page: {phone_error}")
    elif gb.students:
        st.caption(f"The phone page is output/{phone_path(gb).name}. It is rewritten whenever the folder changes "
                   "or an entry is saved.")
    with st.expander("Files read"):
        for f in gb.files:
            st.caption(f"**{f.path.name}**  \n{f.kind}, modified {f.modified:%b %d %H:%M}")

st.title(gb.title or "Mastery gradebook")
if not gb.levels.ok:
    st.error("The mark levels in course.toml cannot be used, so no marks are read: " + " ".join(gb.levels.problems)
             + " Fix them on the Setup tab.")

if not gb.students:
    st.warning("No roster found. Put the registrar's class list (a CSV with LastName, FirstName and Email) in exports/.")
    st.stop()

if gb.new_changes:
    lines = [f"{r['Student']} {r['Standard']} ({r['Sitting']}) {r['From']} → {r['To']}" for r in gb.new_changes]
    listed = "; ".join(lines[:8]) + (f"; and {len(lines) - 8} more" if len(lines) > 8 else "")
    st.info(f"{len(lines)} mark{'s' if len(lines) > 1 else ''} changed since the previous download: {listed}. "
            "The record of every change is on the Revisions tab.", icon=":material/published_with_changes:")

warnings = gb.all_warnings()  # after gb.manual is read, since the office-hour checks use it
tab_names = (["Summary", "Students"] + [s.label for s in gb.sittings if not s.office]
             + (["Office hours"] if gb.office_on else [])
             + ["Revisions", "Manual entries", "Setup", f"Warnings ({len(warnings)})"])
tabs = dict(zip(tab_names, st.tabs(tab_names)))

# -- summary
with tabs["Summary"]:
    s = gb.summary()
    c = st.columns(5)
    c[0].metric("Students", len(gb.students), border=True)
    c[1].metric("Sittings loaded", len(gb.sittings), border=True)
    c[2].metric("Standards assessed", f"{gb.assessed_count} of {gb.planned}" if gb.planned else gb.assessed_count,
                border=True)
    c[3].metric(f"Median standards {gb.levels.at}", "–" if s["median"] is None else f"{s['median']:g}", border=True,
                help=f"Mean {s['mean']:.2f}" if s["mean"] is not None else None)
    c[4].metric("Pending revisions", len(gb.pending_revisions()), border=True)

    if not gb.sittings:
        st.info("No Gradescope exports found yet. Put an assessment's export in exports/ and press Reload.")
    else:
        left, right = st.columns([3, 2])
        with left:
            st.subheader("Where each standard stands")
            st.altair_chart(standards_chart(gb), width="stretch")
        with right:
            st.subheader(f"Students by number of standards {gb.levels.at}")
            st.altair_chart(histogram(gb), width="stretch")

        left, right = st.columns(2)
        with left:
            st.subheader(f"Median standards {gb.levels.at} after each sitting")
            st.altair_chart(median_chart(gb), width="stretch")
            st.caption(f"The band runs from the lower to the upper quartile. Each sitting counts the standards {gb.levels.at} "
                       "from that sitting and the ones before it, with later revisions included.")
        with right:
            st.subheader(f"Students who reached {gb.levels.goal} on each standard at each sitting")
            st.dataframe(new_m_frame(gb), hide_index=True, placeholder="")
            st.caption(f"Each row counts the students who reached {gb.levels.goal} on that standard at that sitting, with later "
                       "revisions of that sitting's marks included. A blank means the standard was not on that "
                       f"sitting. The total is the number of students {gb.levels.at} now.")

        with st.expander("The numbers behind these charts"):
            st.caption(f"Median, mean and quartiles of standards {gb.levels.at} after each sitting")
            st.dataframe(by_sitting_frame(gb)[["Sitting", f"Median {gb.levels.at}", f"Mean {gb.levels.at}", "Lower quartile",
                                               "Upper quartile"]], hide_index=True)
            table = standards_frame(gb).pivot(index="Standard", columns="Status", values="Students")
            st.caption("Current status of each standard")
            st.dataframe(table.reindex(index=gb.standards,
                                       columns=[gb.levels.status_label(x) for x in gb.levels.statuses]))

# -- students
with tabs["Students"]:
    df = students_frame(gb)
    query = st.text_input("Find a student", placeholder="Name or email", label_visibility="collapsed")
    shown = df
    if query:
        q = query.lower()
        mask = df.apply(lambda r: q in f"{r['First Name']} {r['Last Name']} {r['Email']}".lower(), axis=1)
        shown = df[mask]
    styler = shown.style.map(style_marks, subset=gb.standards).map(style_grade, subset=["Base grade"])
    config = {
        "Last Name": st.column_config.TextColumn(pinned=True),
        "First Name": st.column_config.TextColumn(pinned=True),
        f"Standards {gb.levels.at}": st.column_config.ProgressColumn(
            min_value=0, max_value=max(gb.planned, len(gb.standards), 1), format="%d"),
        "Homework": st.column_config.NumberColumn(format="%.0f%%",
                                                  help=f"From {gb.canvas.path.name}" if gb.canvas else None),
        "Base grade": st.column_config.TextColumn(
            help="Shown once every planned standard has been assessed."),
    }
    config |= {std: st.column_config.TextColumn(width=48, help=gb.describe(std) or None) for std in gb.standards}
    event = st.dataframe(styler, hide_index=True, on_select="rerun", selection_mode="single-row", key="students",
                         height=min(38 + 35 * len(shown), 760), column_config=config)
    st.caption(f"Select a row to open that student's record. {gb.levels.held} on a sitting's tab means the "
               f"standard was already {gb.levels.at}.")
    picked = event.selection.rows if event is not None else []
    email = shown.iloc[picked[0]]["Email"] if picked else None
    if email != st.session_state.get("card_for"):
        st.session_state.card_for = email
        if email:
            student_card(gb, email)

# -- one tab per Gradescope sitting
for k, sit in enumerate(gb.sittings):
    if sit.office:
        continue
    with tabs[sit.label]:
        df = sitting_frame(gb, k)
        st.caption(f"{sit.name}" + (f", {sit.date:%A %B} {sit.date.day}" if sit.date else "")
                   + f". From {sit.path.name}, downloaded {sit.modified:%b %d %H:%M}.")
        st.dataframe(df.style.map(style_marks, subset=sit.standards), hide_index=True,
                     height=min(38 + 35 * len(df), 760),
                     column_config={"Last Name": st.column_config.TextColumn(pinned=True),
                                    "First Name": st.column_config.TextColumn(pinned=True)})
        names = {m: gb.levels.here_label(m) for m in gb.levels.names + [HELD, None]}
        counts = {std: {names[m]: n for m, n in c.items()} for std, c in gb.sitting_counts(k).items()}
        st.dataframe(pd.DataFrame(counts))

# -- office hours
if gb.office_on:
    with tabs["Office hours"]:
        kinds = gb.office_kinds
        names = {s.email: f"{s.last}, {s.first}" for s in gb.students}
        flash = st.session_state.pop("office_flash", None)
        if flash:
            st.success(flash, icon=":material/check:")
        label = gb.cfg.get("office_hours", {}).get("label") or "OH"
        st.caption(f"The attempts dated between two Gradescope sittings count as one more sitting, {label}, placed "
                   "between them. A standard's status is still the best mark over all sittings, so an M entered "
                   "here counts at once on the Students and Summary tabs and in the Canvas upload file.")

        with st.form("office_add", clear_on_submit=True):
            c = st.columns([1.3, 2.7, 1.3, 1.5, 1.8])
            when = c[0].date_input("Date", value="today", format="YYYY-MM-DD", key="oh_date")
            who = c[1].selectbox("Student", list(names), index=None, format_func=names.get,
                                 placeholder="Type a name", key="oh_student")
            std = c[2].selectbox("Standard", gb.standards, index=None, placeholder="Choose", key="oh_standard")
            mark = c[3].radio("Mark", gb.levels.names, index=None, horizontal=True, key="oh_mark")
            # The first kind still open today, so that a later window is picked once the earlier one ends.
            ends = [engine.to_date((gb.kind_settings(k) or {}).get("before")) for k in kinds]
            first_open = next((i for i, e in enumerate(ends) if e is None or e > dt.date.today()), 0)
            kind = c[4].selectbox("Kind", kinds, index=first_open if kinds else None, key="oh_kind",
                                  disabled=not kinds, help=None if kinds else "course.toml lists no kinds.")
            added = st.form_submit_button("Add attempt", type="primary", icon=":material/add:")
        if added:
            if not (who and std and mark):
                st.error("Choose a student, a standard and a mark, then press Add attempt again.")
            else:
                engine.add_office_attempt(gb, when, who, std, mark, kind or "")
                st.session_state.office_flash = (f"Added {names[who]}, {std}, {mark}" + (f", {kind}" if kind else "")
                                                 + f", {day(when)}.")
                st.rerun()

        for w in gb.office_warnings():
            st.warning(w)

        st.subheader("Attempts")
        if not gb.office_rows:
            st.caption("No attempts yet.")
        else:
            # As on the Manual entries tab, the editor starts from the file as it was at the last reload. Each
            # change is written to the file at once, which reloads the gradebook and so restarts the editor.
            if st.session_state.get("office_for") != gb.loaded_at:
                st.session_state.office_base = office_frame(gb)
                st.session_state.office_for = gb.loaded_at
                st.session_state.office_version = st.session_state.get("office_version", 0) + 1
            obase = st.session_state.office_base
            okey = f"office_editor_{st.session_state.office_version}"

            def save_office():
                state = st.session_state[okey]
                edited = {int(obase.index[int(i)]): {c: v for c, v in ch.items() if c in ("Date", "Standard", "Mark", "Kind")}
                          for i, ch in state.get("edited_rows", {}).items()}
                deleted = [int(obase.index[int(i)]) for i in state.get("deleted_rows", [])]
                if any(edited.values()) or deleted:
                    engine.save_office_edits(FOLDER, edited, deleted)

            st.data_editor(
                obase, hide_index=True, num_rows="delete", key=okey, on_change=save_office,
                disabled=["Student", "Email", "Counts as", "Entered"], height=min(38 + 35 * len(obase), 560),
                column_config={
                    "Date": st.column_config.DateColumn(format="YYYY-MM-DD", required=True),
                    "Standard": st.column_config.SelectboxColumn(options=gb.standards, required=True),
                    "Mark": st.column_config.SelectboxColumn(options=gb.levels.names, required=True),
                    "Kind": st.column_config.SelectboxColumn(options=kinds),
                    "Counts as": st.column_config.TextColumn(
                        help="An attempt at a standard the last standards assessment gave R is a revision of that "
                             "R, and does not count toward the limit of its kind."),
                    "Entered": st.column_config.TextColumn(help="When the attempt was added here."),
                })
            st.caption(f"When a student fixes {'an R' if gb.levels.revisable_names == ['R'] else 'a mark to revise'}"
                       ", change its mark here. To remove an attempt entered by mistake, "
                       "select its row and delete it. Each change is saved to records/office_hours.csv at once, "
                       "and a changed or deleted mark is kept in the record on the Revisions tab. Before the first "
                       "change of each day, the file is copied to records/office_hours.backup.csv.")

# -- revisions
with tabs["Revisions"]:
    st.subheader(f"Still {'at ' + gb.levels.to_revise if len(gb.levels.revisable_names) == 1 else 'to revise'}")
    pending = gb.pending_revisions()
    if not pending:
        st.success("No pending revisions.")
    else:
        df = pd.DataFrame([{"Student": s.name, "Email": s.email, "Standard": std, "Sitting": sit.label}
                           for s, std, sit in pending])
        st.dataframe(df, hide_index=True, height=min(38 + 35 * len(df), 760))
        st.caption("Every standard still at R. It leaves this list once its mark is changed on Gradescope "
                   "and the export is downloaded again, or, for an office-hour attempt, once its mark is changed "
                   "on the Office hours tab.")
    st.subheader("Changes recorded")
    if gb.changes:
        df = changes_frame(gb.changes)
        st.dataframe(df, hide_index=True, height=min(38 + 35 * len(df), 560))
        st.caption("Each mark that differs from the previous download of the same export, newest first. "
                   "The record is kept in records/changes.csv.")
    else:
        st.caption("Nothing yet. When a new download of an export changes a mark, the change is recorded here.")

# -- manual entries
with tabs["Manual entries"]:
    cols = gb.manual_columns()
    # The editor starts from manual.csv as it was at the last reload, and each edit is written
    # straight to the file, so the editor's own copy never has to be reset while you type.
    if st.session_state.get("manual_for") != gb.loaded_at:
        st.session_state.manual_base = manual_frame(gb)
        st.session_state.manual_for = gb.loaded_at
        st.session_state.manual_version = st.session_state.get("manual_version", 0) + 1
    base = st.session_state.manual_base
    key = f"manual_editor_{st.session_state.manual_version}"

    def autosave():
        edits = st.session_state[key].get("edited_rows", {})
        out = {}
        for i, changed in edits.items():
            row_email = base.iloc[int(i)]["Email"]
            out[row_email] = {c: manual_text(gb, c, v) for c, v in changed.items() if c in cols}
        if out:
            engine.save_manual(gb, out)
            st.session_state.saved_at = dt.datetime.now()

    config = {}
    for c in gb.cfg.get("manual", []):
        name, kind = c["name"], c.get("type", "text")
        if kind == "percent":
            config[name] = st.column_config.NumberColumn(min_value=0, max_value=100, step=0.1, format="%.1f%%")
        elif kind == "integer":
            config[name] = st.column_config.NumberColumn(min_value=0, step=1, format="%d")
        elif kind == "yes/no":
            config[name] = st.column_config.CheckboxColumn()
        elif kind == "choice":
            config[name] = st.column_config.SelectboxColumn(options=c.get("choices", []))
        else:
            config[name] = st.column_config.TextColumn()
    config |= {"Last Name": st.column_config.TextColumn(pinned=True),
               "First Name": st.column_config.TextColumn(pinned=True)}
    st.data_editor(base, hide_index=True, disabled=["Last Name", "First Name", "Email"], column_config=config,
                   key=key, on_change=autosave, placeholder="", height=min(38 + 35 * len(base), 760))
    saved = st.session_state.get("saved_at")
    st.caption((f"Saved {saved:%H:%M:%S}. " if saved else "")
               + "Each change is saved to records/manual.csv as soon as you leave the cell. Before the first "
               "change of each day, the file is copied to records/manual.backup.csv. If you edit manual.csv in "
               "Excel while the dashboard is open, press Reload before typing here.")

# -- setup
with tabs["Setup"]:
    cfg = engine.load_config(FOLDER)
    course, gs = cfg["course"], cfg["gradescope"]
    a, b = st.columns(2)
    title = a.text_input("Course title", course.get("title", ""))
    term = b.text_input("Term", course.get("term", ""))
    output = a.text_input("Workbook file name", course.get("output", "Gradebook.xlsx"))
    planned = b.number_input("Standards planned for the quarter", min_value=0, step=1,
                             value=int(course.get("planned_standards", 0)))

    st.subheader("Base-grade checklist")
    groups = list(cfg.get("groups", {}).keys())
    at_col = f"Standards {gb.levels.at}"
    grade_rows = []
    for row in cfg.get("grade", []):
        r = {"Grade": row.get("letter", ""), at_col: row.get("standards"),
             "Homework %": row["homework"] * 100 if "homework" in row else None}
        r |= {g: row.get(g) for g in groups}
        grade_rows.append(r)
    grades = st.data_editor(pd.DataFrame(grade_rows, columns=["Grade", at_col, "Homework %"] + groups),
                            num_rows="dynamic", hide_index=True, key="grade_editor",
                            column_config={"Homework %": st.column_config.NumberColumn(format="%.0f%%")})
    st.caption("The base grade is the first row whose requirements are all met, and F if none is. Groups of "
               "standards are defined in course.toml.")

    st.subheader("Gradescope")
    pattern = st.text_input("How a standard appears in a question title", gs.get("standard_pattern", r"S\d+"),
                            help="A regular expression. S\\d+ finds S01 in “1: S01 (1.0 pts)”.")
    st.markdown("**Mark levels**")
    level_rows = levels_editor(cfg.get("level", []), "setup_levels")
    with st.expander("Check against the exports in the folder"):
        exports_preview(pattern, level_rows)

    if st.button("Save settings", type="primary", icon=":material/save:"):
        trouble = levels.problems(level_rows)
        try:
            re.compile(pattern)
        except re.error:
            trouble.append("The pattern for standards is not a valid regular expression.")
        if trouble:
            st.error("Not saved. " + " ".join(trouble))
        else:
            cfg["course"].update(title=title, term=term, output=output, planned_standards=int(planned))
            cfg["gradescope"].update(standard_pattern=pattern)
            cfg["level"] = level_rows
            new_grades = []
            for _, r in grades.iterrows():
                if not str(r["Grade"] or "").strip():
                    continue
                row = {"letter": str(r["Grade"]).strip()}
                if not missing(r[at_col]):
                    row["standards"] = int(r[at_col])
                if not missing(r["Homework %"]):
                    row["homework"] = round(float(r["Homework %"]) / 100, 4)
                for g in groups:
                    if not missing(r[g]):
                        row[g] = int(r[g])
                new_grades.append(row)
            cfg["grade"] = new_grades
            engine.save_config(FOLDER, cfg)
            st.cache_resource.clear()
            st.toast("Saved to course.toml")
            st.rerun()
    st.caption("Saving rewrites course.toml. Groups, sitting labels, the Canvas homework settings, the manual "
               "columns and the kinds of office-hour attempt are edited in that file directly.")

# -- warnings
with tabs[f"Warnings ({len(warnings)})"]:
    if not warnings:
        st.success("No warnings.")
    for w in warnings:
        st.warning(w)
