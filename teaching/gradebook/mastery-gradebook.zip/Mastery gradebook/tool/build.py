"""Rebuild the gradebook workbook and the phone page from the files in the course folder.

Usage:  python tool/build.py [course folder]
The course folder defaults to the folder that holds tool/.
"""

import sys
from pathlib import Path

sys.dont_write_bytecode = True  # keep tool/__pycache__ out of the synced folder
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from engine import change_text, load  # noqa: E402
from excel_writer import write_workbook  # noqa: E402
from phone_view import write_phone_view  # noqa: E402


def main():
    folder = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE.parent
    gb = load(folder)
    if gb.students:
        # Before the workbook, so that a workbook left open in Excel does not stop it.
        phone, wrote = write_phone_view(gb)
        print(f"Wrote {phone}" if wrote else f"{phone} is up to date")
    path = write_workbook(gb)
    s = gb.summary()
    print(f"{gb.title}: {len(gb.students)} students, {len(gb.sittings)} sitting(s), "
          f"{len(gb.standards)} standard(s), median {gb.levels.at} {s['median']}, "
          f"{len(gb.pending_revisions())} {'p' + gb.levels.pending[1:]}.")
    print(f"Wrote {path}")
    for r in gb.new_changes:
        print(f"Changed since the previous download: {r['Student']} {r['Standard']} ({r['Sitting']}) {change_text(r)}")
    for w in gb.all_warnings():
        print("Warning:", w)


if __name__ == "__main__":
    main()
