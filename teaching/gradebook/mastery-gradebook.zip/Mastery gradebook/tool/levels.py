"""The mark levels of a course, read from course.toml.

A course lists its levels best first, each with a short name (shown in the tables), a label, the
Gradescope score that stands for it, whether it counts as mastered, and whether it can be revised.
The mastered levels come first. A standard's status is its best level over all sittings, and a
revisable level is listed on the Revisions tab until a later mark replaces it.

A course.toml written before levels existed gives its scores as M, R and N under [gradescope]. It is
read as three levels: M mastered, R revisable, N neither.

Uses only the standard library.
"""

from __future__ import annotations

from dataclasses import dataclass

MAX_LEVELS = 6
DECIMALS = 4          # Gradescope scores of a level have at most this many decimal places
TOLERANCE = 1e-7      # a score this close to a level's score is that level
HELD = "(M)"          # the key for a standard already mastered at an earlier sitting; see Levels.held
NOT_ATTEMPTED = "Not attempted"
LEGACY = [
    {"name": "M", "label": "Meets", "score": 1.0, "mastered": True, "revisable": False},
    {"name": "R", "label": "Revise", "score": 0.0001, "mastered": False, "revisable": True},
    {"name": "N", "label": "Not yet", "score": 0.0, "mastered": False, "revisable": False},
]


@dataclass
class Level:
    name: str
    label: str
    score: float
    mastered: bool
    revisable: bool
    rank: int = 0      # higher is better
    slot: int = 0      # index into style.LEVEL_SLOTS, the level's colour


# The colour slots each number of levels uses, best first: green, light green, amber, orange, red and a
# deep green, from style.LEVEL_SLOTS. Three levels use green, amber and red.
SLOTS = {1: [1], 2: [1, 5], 3: [1, 3, 5], 4: [1, 2, 3, 5], 5: [1, 2, 3, 4, 5], 6: [0, 1, 2, 3, 4, 5]}


def level_rows(cfg):
    """The level tables of a configuration, as dicts: [[level]] if it has them, otherwise the M, R and N
    scores of an older course.toml, otherwise none."""
    rows = cfg.get("level")
    if rows:
        return [dict(r) for r in rows]
    g = cfg.get("gradescope", {})
    if any(k in g for k in ("M", "R", "N")):
        return [dict(r, score=float(g[r["name"]])) for r in LEGACY if r["name"] in g]
    return []


def problems(rows):
    """What is wrong with a list of level tables, as sentences; [] when they can be used."""
    out = []
    if not rows:
        return ["No mark levels are set."]
    if len(rows) > MAX_LEVELS:
        out.append(f"There are {len(rows)} levels, and at most {MAX_LEVELS} are allowed.")
    names, scores = [], []
    for i, r in enumerate(rows, 1):
        name = str(r.get("name") or "").strip()
        if not name:
            out.append(f"Level {i} has no name.")
            continue
        if len(name) > 12 or any(ch in name for ch in ",;()→[]"):
            out.append(f"The name “{name}” is too long or has one of the characters , ; ( ) → [ ].")
        if name.lower() in (n.lower() for n in names):
            out.append(f"Two levels are named “{name}”.")
        names.append(name)
        try:
            score = float(r.get("score"))
        except (TypeError, ValueError):
            out.append(f"Level {name} has no Gradescope score.")
            continue
        if abs(round(score, DECIMALS) - score) > 1e-12:
            out.append(f"The score of {name}, {score:g}, has more than {DECIMALS} decimal places.")
        if any(abs(score - s) < 10 ** -DECIMALS / 2 for s in scores):
            out.append(f"Two levels have the score {score:g}.")
        scores.append(score)
        if r.get("mastered") and r.get("revisable"):
            out.append(f"Level {name} is marked both mastered and revisable.")
    flags = [bool(r.get("mastered")) for r in rows]
    if not any(flags):
        out.append("No level counts as mastered.")
    elif flags != sorted(flags, reverse=True):
        out.append("The mastered levels have to come first in the list, since the list runs from best to worst.")
    return out


class Levels:
    """The levels of one course, best first."""

    def __init__(self, rows):
        self.problems = problems(rows)
        self.list: list[Level] = []
        if self.problems:
            return
        n = len(rows)
        for i, r in enumerate(rows):
            self.list.append(Level(name=str(r["name"]).strip(), label=str(r.get("label") or r["name"]).strip(),
                                   score=float(r["score"]), mastered=bool(r.get("mastered")),
                                   revisable=bool(r.get("revisable")), rank=n - i, slot=SLOTS[n][i]))
        self.by_name = {lv.name: lv for lv in self.list}

    @classmethod
    def from_config(cls, cfg):
        return cls(level_rows(cfg))

    @property
    def ok(self):
        return not self.problems

    @property
    def names(self):
        return [lv.name for lv in self.list]

    def canonical(self, text):
        """The level a typed name stands for, ignoring case, or None."""
        t = str(text or "").strip().lower()
        return next((lv.name for lv in self.list if lv.name.lower() == t), None)

    def rank(self, mark):
        lv = self.by_name.get(mark) if self.list else None
        return lv.rank if lv else 0

    def mastered(self, mark):
        lv = self.by_name.get(mark) if self.list else None
        return bool(lv and lv.mastered)

    def revisable(self, mark):
        lv = self.by_name.get(mark) if self.list else None
        return bool(lv and lv.revisable)

    def decode(self, x):
        """The level of a Gradescope score: (name, False), or (None, True) for a score that is no level."""
        if not self.list:
            return None, False
        for lv in self.list:
            if abs(x - lv.score) < TOLERANCE:
                return lv.name, False
        return None, True

    # -- words for headings, so that a course with M, R and N reads as it always has
    @property
    def mastered_names(self):
        return [lv.name for lv in self.list if lv.mastered]

    @property
    def revisable_names(self):
        return [lv.name for lv in self.list if lv.revisable]

    @property
    def goal(self):
        """What a student reaches: "M" when one level is mastered, otherwise "mastery"."""
        m = self.mastered_names
        return m[0] if len(m) == 1 else "mastery"

    @property
    def at(self):
        """ "at M", or "mastered" when several levels count."""
        m = self.mastered_names
        return f"at {m[0]}" if len(m) == 1 else "mastered"

    @property
    def held(self):
        """What a sitting shows for a standard mastered at an earlier one: "(M)", or "(mastered)"."""
        m = self.mastered_names
        return f"({m[0]})" if len(m) == 1 else "(mastered)"

    @property
    def to_revise(self):
        """The revisable level as a word: "R", or "to revise" when there are several or none."""
        r = self.revisable_names
        return r[0] if len(r) == 1 else "to revise"

    @property
    def pending(self):
        """ "Pending R", or "Pending revisions"."""
        r = self.revisable_names
        return f"Pending {r[0]}" if len(r) == 1 else "Pending revisions"

    def display(self, mark):
        """A mark as a table shows it: the level's name, the held text, or ""."""
        return self.held if mark == HELD else (mark or "")

    @property
    def statuses(self):
        """The statuses of a standard, best first, for the stacked bars: every level, then not attempted."""
        return self.names + [NOT_ATTEMPTED]

    def status_label(self, status):
        """ "At M", "R pending", "N" or "Not attempted"."""
        lv = self.by_name.get(status)
        if lv is None:
            return status
        if lv.mastered:
            return f"At {lv.name}"
        if lv.revisable:
            return f"{lv.name} pending"
        return lv.name

    def here_label(self, mark):
        """A row name for a sitting's counts: "M here", "R", "N", "Already at M", "Not attempted"."""
        if mark == HELD:
            return f"Already {self.at}"
        if mark is None:
            return NOT_ATTEMPTED
        return f"{mark} here" if self.mastered(mark) else mark

    def slot(self, status):
        """The colour slot of a status; None for not attempted."""
        lv = self.by_name.get(status)
        return lv.slot if lv else None
