"""The layout of a course folder, and reading the spreadsheets in it.

    course folder/
        course.toml     settings
        exports/        the roster, the Gradescope exports and the Canvas export, as downloaded
        records/        manual.csv and its backup, changes.csv, last_seen.json
        output/         the workbook, the Canvas upload file and the phone page
"""

from __future__ import annotations

import csv
import datetime as dt
import re
from pathlib import Path

import openpyxl

EXPORTS, RECORDS, OUTPUT = "exports", "records", "output"
MANUAL_FILE = "manual.csv"
BACKUP_FILE = "manual.backup.csv"    # manual.csv as it was before the first change of the day
CHANGES_FILE = "changes.csv"         # marks that changed between two downloads of an export
SEEN_FILE = "last_seen.json"         # the marks of each sitting at its last download
OFFICE_FILE = "office_hours.csv"     # attempts in office hours, entered on the Office hours tab
OFFICE_BACKUP = "office_hours.backup.csv"  # office_hours.csv as it was before the first change of the day
UPLOAD_FILE = "Canvas_standards_upload.csv"
# Files the tool writes. They are never read as downloads, wherever they sit.
TOOL_FILES = {MANUAL_FILE.lower(), BACKUP_FILE.lower(), CHANGES_FILE.lower(), UPLOAD_FILE.lower(),
              OFFICE_FILE.lower(), OFFICE_BACKUP.lower()}


def records_dir(folder: Path) -> Path:
    path = Path(folder) / RECORDS
    path.mkdir(exist_ok=True)
    return path


def output_dir(folder: Path) -> Path:
    path = Path(folder) / OUTPUT
    path.mkdir(exist_ok=True)
    return path


def download_files(folder: Path, workbook_name: str):
    """The .csv and .xlsx files in exports/ and in the main folder, except lock files, hidden files
    and the files the tool writes. Each comes with True if it sits in the main folder."""
    folder = Path(folder)
    skip = TOOL_FILES | {workbook_name.lower()}
    out = []
    for where, at_top in ((folder / EXPORTS, False), (folder, True)):
        if not where.is_dir():
            continue
        for path in sorted(where.iterdir()):
            if (path.is_file() and path.suffix.lower() in {".csv", ".xlsx"}
                    and not path.name.startswith(("~$", ".")) and path.name.lower() not in skip):
                out.append((path, at_top))
    return out


def norm(h):
    return re.sub(r"\s+", " ", str(h if h is not None else "")).strip().lower()


def read_rows(path: Path):
    """All rows of the first sheet of an .xlsx, or of a .csv, padded to the header's length."""
    if path.suffix.lower() == ".xlsx":
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        try:
            rows = [list(r) for r in wb.worksheets[0].iter_rows(values_only=True)]
        finally:
            wb.close()
    else:
        rows = []
        for enc in ("utf-8-sig", "cp1252"):
            try:
                with open(path, newline="", encoding=enc) as fh:
                    rows = [list(r) for r in csv.reader(fh)]
                break
            except UnicodeDecodeError:
                continue
    if not rows:
        return []
    width = len(rows[0])
    return [r + [None] * (width - len(r)) for r in rows]


def classify(header):
    """What a downloaded file is, from its header row: "canvas", "export" (Gradescope), "roster"
    (the registrar's class list, whose headers are LastName and FirstName with no space) or None."""
    names = {norm(h) for h in header}
    if {"student", "id", "sis user id", "sis login id"} <= names:
        return "canvas"
    if {"first name", "last name", "email", "total score"} <= names:
        return "export"
    if {"lastname", "firstname", "email"} <= names:
        return "roster"
    return None


def to_float(v):
    if v is None or (isinstance(v, str) and not v.strip()):
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def to_date(v):
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    if isinstance(v, (int, float)):
        return (dt.datetime(1899, 12, 30) + dt.timedelta(days=float(v))).date()
    if isinstance(v, str) and v.strip():
        text = v.strip()
        for fmt, width in (("%Y-%m-%d", 10), ("%m/%d/%Y", None), ("%m/%d/%y", None)):
            try:  # the last two are how Excel may save a date it was given as 2026-11-06
                return dt.datetime.strptime(text[:width] if width else text.split()[0], fmt).date()
            except ValueError:
                continue
        return None
    return None
