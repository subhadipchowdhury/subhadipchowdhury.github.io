"""Checks that this computer has what the gradebook needs, and offers to install anything missing.

Usage:  python tool/check_setup.py [--dashboard]
Without --dashboard it checks only what the Excel build needs. The exit status is 0 when
everything is in place, so the launchers stop with a message otherwise.

Streamlit is pinned to the version the dashboard was tested with. To move to a newer one,
test the dashboard with it, then change STREAMLIT_PIN and TESTED_STREAMLIT below.
"""

import re
import subprocess
import sys
import sysconfig
from pathlib import Path

MIN_PYTHON = (3, 11)       # course.toml is read with tomllib
MIN_STREAMLIT = (1, 54)    # 1.54 fixes a Windows security advisory, and the dashboard uses widgets from 1.46 on
TESTED_STREAMLIT = (1, 66)
STREAMLIT_PIN = "streamlit~=1.66.0"   # 1.66 or a later bug-fix release of 1.66, never 1.67


def version(text):
    m = re.match(r"(\d+)\.(\d+)", text or "")
    return (int(m.group(1)), int(m.group(2))) if m else (0, 0)


def installed_version(module):
    """The version of an importable module, None if it is not installed. Checked in a fresh
    interpreter, so a package installed a moment ago is seen."""
    out = subprocess.run([sys.executable, "-c", f"import {module}; print({module}.__version__)"],
                         capture_output=True, text=True)
    return out.stdout.strip() if out.returncode == 0 else None


def missing_packages(dashboard):
    """What has to be installed before the launcher can go on: (requirement, reason) pairs."""
    needs = []
    if installed_version("openpyxl") is None:
        needs.append(("openpyxl", "not installed"))
    if dashboard:
        v = installed_version("streamlit")
        if v is None:
            needs.append((STREAMLIT_PIN, "not installed"))
        elif version(v) < MIN_STREAMLIT:
            needs.append((STREAMLIT_PIN, f"version {v} is older than {MIN_STREAMLIT[0]}.{MIN_STREAMLIT[1]}"))
    return needs


def untested_streamlit():
    """The installed Streamlit version if it works but is not the tested one, otherwise None."""
    v = installed_version("streamlit")
    if v is None or version(v) < MIN_STREAMLIT or version(v) == TESTED_STREAMLIT:
        return None
    return v


def ask(question):
    try:
        return input(question).strip().lower() in {"y", "yes"}
    except EOFError:
        return False


def show(cmd):
    return "  " + " ".join(f'"{c}"' if (" " in c or "~" in c) else c for c in cmd)


def pip_command():
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade"]
    if sys.prefix == sys.base_prefix:  # not inside a virtual environment
        cmd.append("--user")
        if (Path(sysconfig.get_path("stdlib")) / "EXTERNALLY-MANAGED").exists():  # Homebrew's Python on the Mac
            cmd.append("--break-system-packages")
    return cmd


def main():
    dashboard = "--dashboard" in sys.argv[1:]
    if sys.version_info[:2] < MIN_PYTHON:
        print(f"The gradebook needs Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} or later, but {sys.executable} "
              f"is Python {sys.version.split()[0]}.")
        return 1

    needs = missing_packages(dashboard)
    if needs:
        print("The gradebook needs the following Python packages:")
        for name, why in needs:
            print(f"  {name} ({why})")
        if subprocess.run([sys.executable, "-m", "pip", "--version"], capture_output=True).returncode != 0:
            boot = [sys.executable, "-m", "ensurepip", "--upgrade"] + (["--user"] if sys.prefix == sys.base_prefix else [])
            print("\nThis Python has no pip, the program that installs packages. It can be added with")
            print(show(boot))
            if not ask("\nAdd pip now? [y/N] ") or subprocess.run(boot).returncode != 0:
                print("Nothing was installed.")
                return 1
        cmd = pip_command() + [name for name, _ in needs]
        print("\nThey can be installed for this user account with")
        print(show(cmd))
        if not ask("\nInstall them now? [y/N] "):
            print("Nothing was installed.")
            return 1
        if subprocess.run(cmd).returncode != 0:
            print("\nThe installation failed. The messages above say why.")
            return 1
        still = missing_packages(dashboard)
        if still:
            print("\nThe installation finished, but these are still missing: " + ", ".join(n for n, _ in still))
            return 1
        print("\nInstalled.\n")

    v = untested_streamlit() if dashboard else None
    if v:
        tested = f"{TESTED_STREAMLIT[0]}.{TESTED_STREAMLIT[1]}"
        print(f"Streamlit {v} is installed, but the dashboard was tested with Streamlit {tested}. "
              "It will probably work, but a feature may have changed.")
        cmd = pip_command() + [STREAMLIT_PIN]
        print(f"\nStreamlit {tested} can be installed for this user account with")
        print(show(cmd))
        if ask(f"\nSwitch to Streamlit {tested}? [y/N] "):
            if subprocess.run(cmd).returncode != 0:
                print(f"\nThe switch failed, so the dashboard opens with Streamlit {v}.\n")
            else:
                print("\nSwitched.\n")
        else:
            print(f"Opening the dashboard with Streamlit {v}.\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
