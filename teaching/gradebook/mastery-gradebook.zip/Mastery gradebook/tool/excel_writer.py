"""Writes the gradebook workbook from a loaded Gradebook. The workbook is an output only:
every run replaces it, so nothing typed into it survives."""

from __future__ import annotations

import datetime as dt
import re
from pathlib import Path

from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

import style
from engine import HELD, Gradebook, change_text

INK, MUTED = style.excel(style.INK), style.excel(style.MUTED)
HEADER_FILL = PatternFill("solid", fgColor=style.excel(style.HEADER))
BOLD = Font(bold=True, color=INK)
THIN = Side(style="thin", color=style.excel(style.HEADER))
GRID = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
CENTER = Alignment(horizontal="center", vertical="center")


def _fill(gb, mark):
    tint = style.cell(gb.levels, mark)[0]
    return PatternFill("solid", fgColor=style.excel(tint))


def _sheet_name(name, used):
    name = re.sub(r"[\[\]:*?/\\]", "-", name)[:31] or "Sheet"
    base, n = name, 2
    while name in used:
        name = f"{base[:28]} {n}"
        n += 1
    used.add(name)
    return name


def _header(ws, columns, widths=None):
    for j, title in enumerate(columns, 1):
        c = ws.cell(row=1, column=j, value=title)
        c.font, c.fill, c.border = BOLD, HEADER_FILL, GRID
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.row_dimensions[1].height = 30
    for j, w in enumerate(widths or [], 1):
        ws.column_dimensions[get_column_letter(j)].width = w


def _mark_cell(ws, row, col, gb, mark):
    c = ws.cell(row=row, column=col, value=gb.levels.display(mark))
    c.fill, c.alignment, c.border = _fill(gb, mark), CENTER, GRID
    c.font = Font(color=MUTED if mark == HELD else INK, bold=gb.levels.mastered(mark))
    return c


def _manual_cell(ws, row, col, gb, email, name):
    value = gb.manual_value(email, name)
    kind = gb.manual_type(name)
    if kind == "yes/no":
        value = "yes" if value else ""
    c = ws.cell(row=row, column=col, value=value)
    if kind == "percent":
        c.number_format = "0%"
    c.border = GRID
    return c


def _students(ws, gb: Gradebook):
    manual = gb.manual_columns()
    cols = ["Last Name", "First Name", "Email", "Base grade", f"Standards {gb.levels.at}", "Homework"] + gb.standards + manual
    cols += [s.label for s in gb.sittings]
    widths = [16, 13, 28, 10, 11, 11] + [6] * len(gb.standards) + [max(10, len(m) + 2) for m in manual]
    widths += [16] * len(gb.sittings)
    _header(ws, cols, widths)
    first_std = 7
    if gb.canvas is not None:
        ws.cell(row=1, column=6).comment = Comment(f"From {gb.canvas.path.name}", "Gradebook")
    for j, std in enumerate(gb.standards):
        text = gb.describe(std) or std
        sit = gb.first_assessed(std)
        text += f"\nFirst assessed: {sit.label}" if sit else "\nNot assessed yet"
        ws.cell(row=1, column=first_std + j).comment = Comment(text, "Gradebook")
    for j, sit in enumerate(gb.sittings):
        col = first_std + len(gb.standards) + len(manual) + j
        ws.cell(row=1, column=col).comment = Comment(f"Standards first mastered at {sit.name}", "Gradebook")

    for i, s in enumerate(gb.students, 2):
        ws.cell(row=i, column=1, value=s.last)
        ws.cell(row=i, column=2, value=s.first)
        ws.cell(row=i, column=3, value=s.email)
        ws.cell(row=i, column=4, value=gb.base_grade(s.email) or "").alignment = CENTER
        ws.cell(row=i, column=5, value=gb.count_m(s.email)).alignment = CENTER
        hw = ws.cell(row=i, column=6, value=gb.homework_score(s.email))
        hw.number_format, hw.alignment = "0%", CENTER
        for j, std in enumerate(gb.standards):
            _mark_cell(ws, i, first_std + j, gb, gb.mark(s.email, std))
        for j, name in enumerate(manual):
            _manual_cell(ws, i, first_std + len(gb.standards) + j, gb, s.email, name)
        for j, _ in enumerate(gb.sittings):
            col = first_std + len(gb.standards) + len(manual) + j
            ws.cell(row=i, column=col, value=", ".join(gb.mastered_at(s.email, j)))

    last = len(gb.students) + 1
    ws.freeze_panes = ws.cell(row=2, column=4)
    ws.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{last}"

    # Counts under the table.
    r = last + 2
    for label in gb.levels.statuses:
        name = gb.levels.status_label(label)
        name = f"Students {name[0].lower()}{name[1:]}" if gb.levels.mastered(label) else name
        ws.cell(row=r, column=3, value=name).font = BOLD
        for j, std in enumerate(gb.standards):
            c = ws.cell(row=r, column=first_std + j, value=gb.standard_counts(std)[label])
            c.alignment = CENTER
        r += 1
    s = gb.summary()
    for name, key in ((f"Median standards {gb.levels.at}", "median"), (f"Mean standards {gb.levels.at}", "mean")):
        ws.cell(row=r, column=3, value=name).font = BOLD
        c = ws.cell(row=r, column=5, value=s[key])
        c.alignment, c.number_format = CENTER, "0.0"
        r += 1


def _sitting_sheet(ws, gb: Gradebook, k):
    sit = gb.sittings[k]
    revise = bool(gb.levels.revisable_names)
    cols = (["Last Name", "First Name", "Email", "Status"] + sit.standards + ["Mastered here"]
            + ([f"{gb.levels.to_revise[0].upper()}{gb.levels.to_revise[1:]} here"] if revise else []))
    _header(ws, cols, [16, 13, 28, 10] + [7] * len(sit.standards) + [16, 12])
    for i, s in enumerate(gb.students, 2):
        ws.cell(row=i, column=1, value=s.last)
        ws.cell(row=i, column=2, value=s.first)
        ws.cell(row=i, column=3, value=s.email)
        ws.cell(row=i, column=4, value=sit.status.get(s.email, "Not in export"))
        rs = []
        for j, std in enumerate(sit.standards):
            m = gb.sitting_mark(s.email, k, std)
            _mark_cell(ws, i, 5 + j, gb, m)
            if gb.levels.revisable(m):
                rs.append(std)
        ws.cell(row=i, column=5 + len(sit.standards), value=", ".join(gb.mastered_at(s.email, k)))
        if revise:
            ws.cell(row=i, column=6 + len(sit.standards), value=", ".join(rs))
    last = len(gb.students) + 1
    ws.freeze_panes = ws.cell(row=2, column=4)
    ws.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{last}"
    r = last + 2
    counts = gb.sitting_counts(k)
    names = {m: gb.levels.here_label(m) for m in gb.levels.names + [HELD, None]}
    for mark, name in names.items():
        ws.cell(row=r, column=3, value=name).font = BOLD
        for j, std in enumerate(sit.standards):
            ws.cell(row=r, column=5 + j, value=counts[std][mark]).alignment = CENTER
        r += 1
    note = f"{sit.name}, {sit.date:%A %B} {sit.date.day}, {sit.date.year}" if sit.date else sit.name
    ws.cell(row=r + 1, column=1, value=f"{note}. From {sit.path.name}, downloaded {sit.modified:%Y-%m-%d %H:%M}.").font = Font(italic=True, color=MUTED)
    ws.cell(row=r + 2, column=1, value=f"{gb.levels.held} means the standard was already {gb.levels.at} before this sitting.").font = Font(italic=True, color=MUTED)


def _summary(ws, gb: Gradebook):
    ws.column_dimensions["A"].width = 26
    for col in "BCDEFGH":
        ws.column_dimensions[col].width = 14
    ws["A1"] = gb.title
    ws["A1"].font = Font(bold=True, size=14, color=INK)
    ws["A2"] = (f"Rebuilt {dt.datetime.now():%Y-%m-%d %H:%M} from the files in {gb.folder.name}. "
                "Every rebuild replaces this workbook, so make entries by hand in the dashboard's "
                "Manual entries tab or in records/manual.csv, not here.")
    ws["A2"].font = Font(italic=True, color=MUTED)
    s = gb.summary()
    facts = [
        ("Students", len(gb.students)),
        ("Sittings loaded", len(gb.sittings)),
        ("Standards assessed", gb.assessed_count),
        ("Standards planned", gb.planned or ""),
        (f"Median standards {gb.levels.at}", s["median"]),
        ("Pending revisions" + (f" ({gb.levels.revisable_names[0]})" if len(gb.levels.revisable_names) == 1 else ""),
         len(gb.pending_revisions())),
    ]
    for i, (k, v) in enumerate(facts, 4):
        ws.cell(row=i, column=1, value=k).font = BOLD
        ws.cell(row=i, column=2, value=v).alignment = CENTER

    # By standard.
    top = 4 + len(facts) + 1
    heads = ["Standard", "Description", "First assessed"] + [gb.levels.status_label(k) for k in gb.levels.statuses]
    for j, h in enumerate(heads, 1):
        c = ws.cell(row=top, column=j, value=h)
        c.font, c.fill, c.border = BOLD, HEADER_FILL, GRID
    for i, std in enumerate(gb.standards, top + 1):
        sit = gb.first_assessed(std)
        counts = gb.standard_counts(std)
        values = [std, gb.describe(std), sit.label if sit else "not yet"] + [counts[k] for k in gb.levels.statuses]
        for j, v in enumerate(values, 1):
            ws.cell(row=i, column=j, value=v).border = GRID
    std_end = top + len(gb.standards)

    if gb.standards:
        chart = BarChart()
        chart.type, chart.grouping, chart.overlap, chart.gapWidth = "bar", "stacked", 100, 60
        chart.title = "Where each standard stands"
        chart.y_axis.title = "Students"
        chart.y_axis.majorGridlines = None
        data = Reference(ws, min_col=4, max_col=3 + len(gb.levels.statuses), min_row=top, max_row=std_end)
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(Reference(ws, min_col=1, min_row=top + 1, max_row=std_end))
        for series, key in zip(chart.series, gb.levels.statuses):
            series.graphicalProperties.solidFill = style.excel(style.status_colour(gb.levels, key))
            series.graphicalProperties.line.solidFill = "FFFFFF"
            series.graphicalProperties.line.width = 19050  # 1.5 pt white gap between segments
        chart.x_axis.scaling.orientation = "maxMin"  # S01 at the top
        chart.x_axis.delete = chart.y_axis.delete = False  # openpyxl 3.1 hides axes otherwise
        chart.legend.position = "b"
        chart.height, chart.width = max(6, 1 + 0.8 * len(gb.standards)), 16
        ws.add_chart(chart, "I4")

    # By sitting: the record as it stood after each sitting, with today's revisions included.
    top2 = std_end + 3
    heads = ["Through sitting", "Date", f"Median {gb.levels.at}", f"Mean {gb.levels.at}", "Lower quartile",
             "Upper quartile"]
    for j, h in enumerate(heads, 1):
        c = ws.cell(row=top2, column=j, value=h)
        c.font, c.fill, c.border = BOLD, HEADER_FILL, GRID
    for i, sit in enumerate(gb.sittings):
        r = top2 + 1 + i
        s = gb.summary(through=i)
        values = [sit.label, sit.date, s["median"], s["mean"], s["q1"], s["q3"]]
        for j, v in enumerate(values, 1):
            c = ws.cell(row=r, column=j, value=v)
            c.border = GRID
            if j == 2 and v:
                c.number_format = "yyyy-mm-dd"
            if 3 <= j <= 6:
                c.number_format = "0.0"
    ws.cell(row=top2 + len(gb.sittings) + 1, column=1,
            value=f"Each row counts the standards {gb.levels.at} from that sitting and the ones before it, "
                  "with revisions made since then included.").font = Font(italic=True, color=MUTED)

    # Standards mastered at each sitting, and the total mastered now.
    top3 = top2 + len(gb.sittings) + 3
    ws.cell(row=top3 - 1, column=1, value=f"Students who reached {gb.levels.goal} on each standard at each sitting").font = BOLD
    for j, h in enumerate(["Sitting"] + gb.standards, 1):
        c = ws.cell(row=top3, column=j, value=h)
        c.font, c.fill, c.border = BOLD, HEADER_FILL, GRID
    rows, total = gb.new_m_table()
    for i, (label, counts) in enumerate([(sit.label, counts) for sit, counts in rows] + [("Total", total)], 1):
        ws.cell(row=top3 + i, column=1, value=label).border = GRID
        for j, std in enumerate(gb.standards, 2):
            c = ws.cell(row=top3 + i, column=j, value=counts[std])
            c.border, c.alignment = GRID, CENTER
        if label == "Total":
            for j in range(1, len(gb.standards) + 2):
                ws.cell(row=top3 + i, column=j).font = BOLD
    ws.cell(row=top3 + len(rows) + 2, column=1,
            value=f"Each row counts the students who reached {gb.levels.goal} on that standard at that sitting, with later "
                  "revisions of that sitting's marks included. A blank means the standard was not on that "
                  f"sitting. The total is the number of students {gb.levels.at} now.").font = Font(italic=True, color=MUTED)
    if len(gb.sittings) > 1:
        line = LineChart()
        line.title = f"Median standards {gb.levels.at} after each sitting"
        line.add_data(Reference(ws, min_col=3, min_row=top2, max_row=top2 + len(gb.sittings)), titles_from_data=True)
        line.set_categories(Reference(ws, min_col=1, min_row=top2 + 1, max_row=top2 + len(gb.sittings)))
        line.series[0].graphicalProperties.line.solidFill = style.excel(style.ACCENT["light"])
        line.series[0].graphicalProperties.line.width = 25400
        line.series[0].marker.symbol = "circle"
        line.legend = None
        line.x_axis.delete = line.y_axis.delete = False
        line.y_axis.scaling.min = 0
        if gb.planned:
            line.y_axis.scaling.max = gb.planned
        line.height, line.width = 7, 16
        ws.add_chart(line, f"I{top2}")


def _office_sheet(ws, gb: Gradebook):
    """The office-hour attempts, oldest first, with the sitting each one counts in."""
    _header(ws, ["Date", "Last Name", "First Name", "Email", "Standard", "Mark", "Kind", "Counts in", "Counts as"],
            [12, 16, 13, 28, 10, 7, 16, 16, 16])
    name = {s.email: s for s in gb.students}
    for i, a in enumerate(gb.office, 2):
        s = name[a.email]
        values = [a.date, s.last, s.first, a.email, a.standard, None, a.kind, gb.sittings[a.sitting].label,
                  f"Fixes {gb.revises(a)} R" if gb.revises(a) else "Retake"]
        for j, v in enumerate(values, 1):
            c = ws.cell(row=i, column=j, value=v)
            c.border = GRID
            if j == 1:
                c.number_format = "yyyy-mm-dd"
        _mark_cell(ws, i, 6, gb, a.mark)
    ws.freeze_panes = ws.cell(row=2, column=1)
    note = (f"From records/{gb.sittings[gb.office[0].sitting].path.name}, entered on the dashboard's Office hours "
            "tab." if gb.office else "No office-hour attempts yet.")
    ws.cell(row=len(gb.office) + 3, column=1, value=note).font = Font(italic=True, color=MUTED)


def _revisions(ws, gb: Gradebook):
    _header(ws, ["Student", "Email", "Standard", "Sitting"], [24, 30, 10, 10])
    pending = gb.pending_revisions()
    for i, (s, std, sit) in enumerate(pending, 2):
        for j, v in enumerate([s.name, s.email, std, sit.label], 1):
            ws.cell(row=i, column=j, value=v).border = GRID
    r = len(pending) + 3
    ws.cell(row=r, column=1,
            value="Changes recorded between downloads" if gb.changes else "No changes recorded yet").font = BOLD
    r += 1
    heads = ["Export downloaded", "Sitting", "Student", "Standard", "Change"]
    for j, h in enumerate(heads, 1):
        c = ws.cell(row=r, column=j, value=h)
        c.font, c.fill, c.border = BOLD, HEADER_FILL, GRID
    for i, row in enumerate(reversed(gb.changes), r + 1):
        values = [row["Export downloaded"], row["Sitting"], row["Student"], row["Standard"], change_text(row)]
        for j, v in enumerate(values, 1):
            ws.cell(row=i, column=j, value=v).border = GRID
    ws.column_dimensions["E"].width = 14


def _warnings(ws, gb: Gradebook):
    ws.column_dimensions["A"].width = 120
    warnings = gb.all_warnings()
    ws["A1"] = "Warnings" if warnings else "No warnings"
    ws["A1"].font = BOLD
    for i, w in enumerate(warnings, 2):
        ws.cell(row=i, column=1, value=w).alignment = Alignment(wrap_text=True)
    r = len(warnings) + 3
    ws.cell(row=r, column=1, value="Files read").font = BOLD
    for i, f in enumerate(gb.files, r + 1):
        ws.cell(row=i, column=1, value=f"{f.path.name}  ({f.kind}, modified {f.modified:%Y-%m-%d %H:%M})")


def write_workbook(gb: Gradebook, path: Path | None = None):
    path = Path(path) if path else gb.workbook_path
    path.parent.mkdir(exist_ok=True)
    wb = Workbook()
    used = set()
    ws = wb.active
    ws.title = _sheet_name("Students", used)
    _students(ws, gb)
    for k, sit in enumerate(gb.sittings):
        if not sit.office:
            _sitting_sheet(wb.create_sheet(_sheet_name(sit.label, used)), gb, k)
    if gb.office_on:
        _office_sheet(wb.create_sheet(_sheet_name("Office hours", used)), gb)
    _summary(wb.create_sheet(_sheet_name("Summary", used)), gb)
    _revisions(wb.create_sheet(_sheet_name("Revisions", used)), gb)
    _warnings(wb.create_sheet(_sheet_name("Warnings", used)), gb)
    wb.save(path)
    return path
