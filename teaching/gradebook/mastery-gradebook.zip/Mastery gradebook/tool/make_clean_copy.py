"""Make a copy of the gradebook tool for another course, with no student data in it.

Usage:  python3 tool/make_clean_copy.py <new folder>

The new folder gets the code, the launchers, .streamlit/ and the new-course README, with an empty
exports/ folder. It gets no course.toml, records/ or output/, so the dashboard opens on its setup page
the first time. The new folder must not exist yet, or be empty. Uses only the standard library.
"""

from __future__ import annotations

import shutil
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent
CODE = ["build.py", "canvas.py", "check_setup.py", "config.py", "dashboard.py", "engine.py", "excel_writer.py",
        "files.py", "levels.py", "make_clean_copy.py", "phone_view.py", "selftest.py", "style.py",
        "launch.sh", "launch.bat", "NEW_COURSE_README.md"]
LAUNCHERS = ["Open Dashboard.command", "Open Dashboard.bat", "Build Excel.command", "Build Excel.bat"]
EXECUTABLE = {"Open Dashboard.command", "Build Excel.command", "launch.sh"}


def make_copy(dest: Path):
    dest = Path(dest).resolve()
    if dest.exists() and any(dest.iterdir()):
        raise SystemExit(f"{dest} is not empty. Choose a new folder.")
    if SOURCE in dest.parents or dest == SOURCE:
        raise SystemExit("Choose a folder outside this course folder.")
    (dest / "tool").mkdir(parents=True, exist_ok=True)
    for name in CODE:
        shutil.copy2(HERE / name, dest / "tool" / name)
    for name in LAUNCHERS:
        shutil.copy2(SOURCE / name, dest / name)
    (dest / ".streamlit").mkdir(exist_ok=True)
    shutil.copy2(SOURCE / ".streamlit" / "config.toml", dest / ".streamlit" / "config.toml")
    shutil.copy2(HERE / "NEW_COURSE_README.md", dest / "README.md")
    (dest / "exports").mkdir(exist_ok=True)
    for name in EXECUTABLE:
        path = dest / name if (dest / name).exists() else dest / "tool" / name
        path.chmod(0o755)
    return dest


def make_zip(folder: Path):
    """A zip of the copy beside it, keeping the launchers executable for the Mac."""
    folder = Path(folder)
    zip_path = folder.with_suffix(".zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in sorted(folder.rglob("*")):
            arc = Path(folder.name) / path.relative_to(folder)
            if path.is_dir():
                info = zipfile.ZipInfo(str(arc) + "/")
                info.external_attr = (0o40755 << 16) | 0x10
                zf.writestr(info, "")
                continue
            info = zipfile.ZipInfo.from_file(path, str(arc))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = ((0o100755 if path.name in EXECUTABLE else 0o100644) << 16)
            zf.writestr(info, path.read_bytes())
    return zip_path


def main():
    if len(sys.argv) != 2:
        print(__doc__)
        return 2
    dest = make_copy(Path(sys.argv[1]).expanduser())
    zip_path = make_zip(dest)
    print(f"Made {dest}")
    print(f"and {zip_path}, the same folder as one file to send.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
