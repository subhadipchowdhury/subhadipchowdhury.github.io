"""Self-test of the gradebook tool on a made-up course, so a change can be checked without student data.

Usage:  python tool/selftest.py
It builds a course folder with six fake students in a temporary folder, runs the engine, the Excel
writer, the Canvas upload and (when Streamlit is installed) the dashboard on it, and compares every
number with the answer worked out by hand below. Nothing outside the temporary folder is touched.
"""

import csv
import datetime as dt
import os
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import openpyxl  # noqa: E402

import engine  # noqa: E402
import levels  # noqa: E402
from config import config_to_toml, load_config  # noqa: E402
from excel_writer import write_workbook  # noqa: E402
from phone_view import write_phone_view  # noqa: E402

try:
    import tomllib
except ModuleNotFoundError:
    tomllib = None

M, R, N = 1.0, 0.0001, 0.0
# (first, last, email login, Gradescope SID, Canvas SIS Login ID)
STUDENTS = [
    ("Ada", "Alpha", "aalpha", "1001A", "aalpha"),
    ("Ben", "Beta", "bbeta", "1002B", "bbeta"),
    ("Cy", "Chi", "cchi", "1003C", "cchi"),
    ("Dee", "Delta", "ddelta", "1004D", "ddelta"),
    ("Eli", "Epsilon", "eepsilon", "1005E", "eepsilon"),
    ("Fay", "Zeta", "fzeta", "1006F", "fzeta-old"),   # matched in Canvas by SIS User ID, not login
]
EMAIL = {s[2]: f"{s[2]}@example.edu" for s in STUDENTS}

COURSE_TOML = """[course]
title = "TEST 101"
term = "Test term"
output = "Gradebook_TEST.xlsx"
planned_standards = 4

[gradescope]
standard_pattern = 'S\\d+'
M = 1.0
R = 0.0001
N = 0.0

[standards]
S01 = "first"
S02 = "second"
S03 = "third"

[canvas]
homework_pattern = '^Homework'
homework_divisor = 0.95

[[grade]]
letter = "A"
standards = 4
homework = 0.90

[[grade]]
letter = "B"
standards = 3
homework = 0.85

[[grade]]
letter = "C"
standards = 2
homework = 0.80

[[grade]]
letter = "D"
standards = 1
homework = 0.75

[[manual]]
name = "Extension used"
type = "yes/no"

[[manual]]
name = "Notes"
type = "text"

[[manual]]
name = "Note standard"
type = "choice"
choices = ["S01", "S02", "S03", "S04"]

[office_hours]
label = "OH"

[[office_hours.kind]]
name = "Window"
per_student = 1
before = 2026-10-30

[[office_hours.kind]]
name = "Note"
per_student = 1
note_column = "Note standard"
"""

failures = []


def check(label, got, want):
    ok = got == want if not isinstance(want, float) else abs(got - want) < 1e-9
    print(("PASS " if ok else "FAIL ") + label + ("" if ok else f": got {got!r}, want {want!r}"))
    if not ok:
        failures.append(label)


def write_roster(path):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["LastName", "FirstName", "MiddleName", "ID", "Dept", "YearOfStudy", "Course", "Units",
                    "Activity", "Grade", "Adviser", "Email", "PronounsOfReference"])
        for first, last, login, *_ in STUDENTS:
            w.writerow([last, first, "", "9999", "Test", "03", "TEST 101", "100", "", "", "", EMAIL[login], ""])


def write_export(path, standards, marks, date, extra_rows=()):
    """marks: {login: [score or None per standard]}; a login missing from marks is a Missing row."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.append(["First Name", "Last Name", "SID", "Email", "Sections", "Total Score", "Max Points", "Status",
               "Submission ID", "Submission Time", "Lateness (H:M:S)", "View Count", "Submission Count"]
              + [f"{i + 1}: {s} (1.0 pts)" for i, s in enumerate(standards)])
    for first, last, login, sid, _ in STUDENTS:
        scores = marks.get(login)
        if scores is None:
            ws.append([first, last, sid, EMAIL[login], "Test", None, len(standards), "Missing"])
            continue
        ws.append([first, last, sid, EMAIL[login], "Test", sum(x or 0 for x in scores), len(standards), "Graded",
                   1, f"{date} 17:00:00 -0500", "00:00:00", 0, 1] + scores)
    for row in extra_rows:
        ws.append(row)
    wb.save(path)


def write_canvas(path):
    hw = {"aalpha": ("10", "9"), "bbeta": ("8", "EX"), "cchi": ("7", "6"), "ddelta": ("", "10"),
          "eepsilon": ("0", "0"), "fzeta": ("9", "9")}
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["Student", "ID", "SIS User ID", "SIS Login ID", "Section", "Homework 1 (101)",
                    "Homework 2 (102)", "Homework 3 (103)", "Standards Assessment 1 (300)", "S01 (201)",
                    "S02 (202)", "S03 (203)", "Homeworks Current Points"])
        w.writerow(["    Points Possible", "", "", "", "", "10", "10", "10", "0", "1", "1", "1", "(read only)"])
        for i, (first, last, login, sid, canvas_login) in enumerate(STUDENTS):
            w.writerow([f"{last}, {first}", str(500 + i), sid, canvas_login, "Test", *hw[login], "", "", "", "", "",
                        "(read only)"])
        w.writerow(["Student, Test", "999", "", "", "Test", "10", "10", "", "", "", "", "", "(read only)"])


def main():
    tmp = Path(tempfile.mkdtemp(prefix="gradebook_selftest_"))
    try:
        run(tmp)
        oral_exam(tmp)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    for test in (level_rules, four_levels, first_run, clean_copy):
        tmp = Path(tempfile.mkdtemp(prefix="gradebook_selftest_"))
        try:
            test(tmp)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    print()
    if failures:
        print(f"{len(failures)} check(s) failed: " + "; ".join(failures))
        sys.exit(1)
    print("All checks passed.")


def run(folder):
    exports = folder / "exports"
    exports.mkdir()
    (folder / "course.toml").write_text(COURSE_TOML, encoding="utf-8")
    write_roster(exports / "TestCourse-01.csv")
    visitor = ["Zed", "Visitor", "9999Z", "zvisitor@example.edu", "Test", 1.0, 3, "Graded", 1,
               "2026-10-14 17:00:00 -0500", "00:00:00", 0, 1, 1.0, 0.0, 0.0]
    sa1 = {"aalpha": [M, M, R], "bbeta": [N, R, M], "cchi": [M, N, N], "ddelta": [R, R, R],
           "eepsilon": [N, N, N]}
    write_export(exports / "Standards_Assessment_1_scores.xlsx", ["S01", "S02", "S03"], sa1, "2026-10-14",
                 extra_rows=[visitor])
    write_canvas(folder / "2026-10-20T1200_Grades-TEST.csv")   # in the main folder on purpose

    # -- first load: one sitting
    gb = engine.load(folder)
    e = EMAIL
    check("roster has six students", len(gb.students), 6)
    check("standards S01-S03", gb.standards, ["S01", "S02", "S03"])
    check("Ada S03 is R", gb.mark(e["aalpha"], "S03"), "R")
    check("Fay, absent, has nothing", gb.mark(e["fzeta"], "S01"), None)
    check("standards at M per student", [gb.count_m(s.email) for s in gb.students], [2, 1, 1, 0, 0, 0])
    check("median standards at M", gb.summary()["median"], 0.5)
    check("S01 counts", gb.standard_counts("S01"), {"M": 2, "R": 1, "N": 2, "Not attempted": 1})
    check("pending revisions", len(gb.pending_revisions()), 5)
    check("visitor reported", any("Zed Visitor" in w for w in gb.warnings), True)
    check("Canvas export in main folder read, with a warning",
          (gb.canvas is not None, any("Grades-TEST.csv is in the main folder" in w for w in gb.warnings)), (True, True))
    check("first load records no changes", (gb.new_changes, (folder / "records" / "last_seen.json").exists()), ([], True))
    check("homework from Canvas (Ada capped, Ben with EX, Dee blank counts 0, Fay matched by SID)",
          [round(gb.homework_score(s.email), 4) for s in gb.students],
          [1.0, round(8 / 9.5, 4), round(13 / 19, 4), round(10 / 19, 4), 0.0, round(18 / 19, 4)])
    check("base grade blank while 3 of 4 standards are assessed", {gb.base_grade(s.email) for s in gb.students}, {None})
    check("manual.csv created in records/", (folder / "records" / "manual.csv").exists(), True)

    # -- a second download of SA1, as "... (1).xlsx": Dee's S01 revision R -> M, Ben's S02 R -> N
    sa1b = dict(sa1, ddelta=[M, R, R], bbeta=[N, N, M])
    newer = exports / "Standards_Assessment_1_scores (1).xlsx"
    write_export(newer, ["S01", "S02", "S03"], sa1b, "2026-10-14", extra_rows=[visitor])
    later = time.time() + 5
    os.utime(newer, (later, later))
    gb = engine.load(folder)
    check("newer download used", gb.sittings[0].path.name, newer.name)
    check("changes recorded", sorted((r["Student"], r["Standard"], r["From"], r["To"]) for r in gb.new_changes),
          [("Ben Beta", "S02", "R", "N"), ("Dee Delta", "S01", "R", "M")])
    gb = engine.load(folder)
    check("reloading records nothing new", (len(gb.new_changes), len(gb.changes)), (0, 2))
    check("change text", engine.change_text({"From": "R", "To": "M"}), "R → M")

    # -- SA2: a retest of S01 and the new S04
    sa2 = {"aalpha": [N, M], "bbeta": [M, M], "cchi": [None, R], "ddelta": [N, N], "eepsilon": [N, N],
           "fzeta": [M, M]}
    write_export(exports / "Standards_Assessment_2_scores.xlsx", ["S01", "S04"], sa2, "2026-10-30")
    gb = engine.load(folder)
    check("two sittings in order", [s.label for s in gb.sittings], ["SA1", "SA2"])
    check("S04 added after the listed standards", gb.standards, ["S01", "S02", "S03", "S04"])
    check("Ada's S01 shows (M) on SA2", gb.sitting_mark(e["aalpha"], 1, "S01"), engine.HELD)
    check("Ben's S01 first mastered at SA2", gb.mastered_at(e["bbeta"], 1), ["S01", "S04"])
    check("SA2 counts for S01", gb.sitting_counts(1)["S01"], {"M": 2, "R": 0, "N": 1, engine.HELD: 3, None: 0})
    check("standards at M after SA2", [gb.count_m(s.email) for s in gb.students], [3, 3, 1, 1, 0, 2])
    check("standards at M through SA1 only", [gb.count_m(s.email, through=0) for s in gb.students], [2, 1, 1, 1, 0, 0])
    check("base grades once all four are assessed", [gb.base_grade(s.email) for s in gb.students],
          ["B", "C", "F", "F", "F", "C"])
    check("warnings for S04", (any("not in course.toml: S04" in w for w in gb.warnings),
                               any("no assignment for S04" in w for w in gb.warnings)), (True, True))

    # -- Canvas upload: only S01-S03 exist in Canvas
    path, stds = engine.write_canvas_upload(gb)
    rows = list(csv.reader(open(path, encoding="utf-8")))
    check("upload in output/", path.parent.name, "output")
    check("upload header", rows[0], ["Student", "ID", "SIS User ID", "SIS Login ID", "Section",
                                     "S01 (201)", "S02 (202)", "S03 (203)"])
    check("upload values, 1 for M and 0 otherwise, test student left out", [r[5:] for r in rows[1:]],
          [["1", "1", "0"], ["1", "0", "1"], ["1", "0", "0"], ["1", "0", "0"], ["0", "0", "0"], ["1", "0", "0"]])
    check("Fay's Canvas IDs copied unchanged", rows[6][:5], ["Zeta, Fay", "505", "1006F", "fzeta-old", "Test"])

    # -- manual entries: one cell changes, the backup holds the day's first state
    before = (folder / "records" / "manual.csv").read_text(encoding="utf-8-sig")
    engine.save_manual(gb, {e["aalpha"]: {"Notes": "hello"}})
    engine.save_manual(gb, {e["bbeta"]: {"Extension used": "yes"}})
    manual = engine.read_manual(folder)
    check("autosaved cells", (manual[e["aalpha"]]["Notes"], manual[e["bbeta"]]["Extension used"]), ("hello", "yes"))
    check("other cells untouched", manual[e["cchi"]]["Notes"], "")
    check("backup is the state before the first change of the day",
          (folder / "records" / "manual.backup.csv").read_text(encoding="utf-8-sig"), before)

    # -- workbook
    out = write_workbook(gb)
    wb = openpyxl.load_workbook(out)
    check("workbook sheets", wb.sheetnames,
          ["Students", "SA1", "SA2", "Office hours", "Summary", "Revisions", "Warnings"])
    ws = wb["Students"]
    header = [c.value for c in ws[1]]
    ada = [c.value for c in ws[2]]
    check("workbook row for Ada", (ada[header.index("Base grade")], ada[header.index("Standards at M")],
                                   ada[header.index("Homework")], ada[header.index("S03")]), ("B", 3, 1.0, "R"))
    cells = [c.value for row in wb["Revisions"].iter_rows() for c in row]
    check("workbook records the changes", ("Dee Delta" in cells, "R → M" in cells, "R → N" in cells),
          (True, True, True))

    # -- settings round trip
    cfg = load_config(folder)
    if tomllib is not None:
        check("course.toml rewritten by the Setup tab reads back the same", tomllib.loads(config_to_toml(cfg)),
              {k: v for k, v in cfg.items() if v or k in ("standards", "groups")})

    # -- the table of standards reached at each sitting, before any office-hour attempt
    rows, total = gb.new_m_table()
    check("reached M at each sitting", [(sit.label, counts) for sit, counts in rows],
          [("SA1", {"S01": 3, "S02": 1, "S03": 1, "S04": None}), ("SA2", {"S01": 2, "S02": None, "S03": None, "S04": 3})])
    check("total row is the number at M now", total, {"S01": 5, "S02": 1, "S03": 1, "S04": 3})

    # -- office hours: two after SA1 (Oct 14) and before SA2 (Oct 30), one after SA2
    office(folder, gb)
    revisions(folder)
    gb = engine.load(folder)
    phone(folder)

    # -- dashboard, when Streamlit is installed
    try:
        import pandas as pd
        from streamlit.testing.v1 import AppTest
    except ImportError:
        print("SKIP dashboard: Streamlit is not installed")
        return
    os.environ["GRADEBOOK_FOLDER"] = str(folder)
    page = folder / "output" / "Gradebook_TEST_phone.html"
    page.unlink()
    at = AppTest.from_file(str(HERE / "dashboard.py"), default_timeout=60)
    at.run()
    check("dashboard runs without errors", [x.value for x in at.exception], [])
    check("dashboard writes the phone page and names it", (page.exists(), any(
        "output/Gradebook_TEST_phone.html" in x.value for x in at.sidebar.caption)), (True, True))
    page_before = page.read_text(encoding="utf-8")
    check("dashboard tabs", [t.label for t in at.tabs][:6],
          ["Summary", "Students", "SA1", "SA2", "Office hours", "Revisions"])
    table = next(d.value for d in at.dataframe if "Sitting" in d.value.columns and "Total" in list(d.value["Sitting"]))
    check("dashboard table of standards reached at each sitting",
          [[None if pd.isna(v) else v for v in row] for row in table.astype(object).values.tolist()],
          [["SA1", 3, 1, 1, None], ["OH after SA1", None, 1, 1, None], ["SA2", 2, None, None, 3],
           ["OH after SA2", 0, 0, None, 1], ["Total", 5, 2, 2, 4]])
    before = len(engine.read_office_rows(folder))
    at.selectbox(key="oh_student").set_value(e["fzeta"])
    at.selectbox(key="oh_standard").set_value("S03")
    at.radio(key="oh_mark").set_value("R")
    at.selectbox(key="oh_kind").set_value("Window")
    next(b for b in at.button if b.label == "Add attempt").click().run()
    rows = engine.read_office_rows(folder)
    check("dashboard form adds an attempt", (len(rows) - before, rows[-1]["Email"], rows[-1]["Standard"],
                                             rows[-1]["Mark"], rows[-1]["Kind"]),
          (1, e["fzeta"], "S03", "R", "Window"))
    check("dashboard rewrites the phone page after an entry",
          page.read_text(encoding="utf-8").count('class="oh"') - page_before.count('class="oh"'), 1)
    check("dashboard confirms the attempt", ([x.value for x in at.exception],
                                             any(x.value.startswith("Added Zeta, Fay, S03, R") for x in at.success)),
          ([], True))
    next(b for b in at.button if b.label == "Write Canvas upload file").click().run()
    check("Canvas button works", any("S01, S02, S03" in x.value for x in at.success), True)
    next(b for b in at.button if b.label == "Write Excel gradebook").click().run()
    check("Excel button works", ([x.value for x in at.exception], any("Gradebook_TEST.xlsx" in x.value for x in at.success)),
          ([], True))


def office(folder, gb):
    """Office-hour attempts on top of SA1 and SA2, with every check of the Office hours tab."""
    e = EMAIL
    check("no office-hour file yet", (engine.read_office_rows(folder), gb.office_on), ([], True))
    engine.add_office_attempt(gb, "2026-10-20", e["eepsilon"], "S02", "M", "Window")
    engine.add_office_attempt(gb, "2026-10-21", e["ddelta"], "S03", "R", "Note")      # no note recorded
    engine.add_office_attempt(gb, "2026-10-22", e["eepsilon"], "S01", "N", "Window")  # a second Window attempt
    engine.add_office_attempt(gb, "2026-11-02", e["cchi"], "S04", "M", "Window")      # Window ends Oct 30
    engine.save_manual(gb, {e["aalpha"]: {"Note standard": "S03"}})
    engine.add_office_attempt(gb, "2026-11-03", e["aalpha"], "S01", "M", "Note")      # note says S03; S01 at M
    rows = engine.read_office_rows(folder)
    rows.append({"Date": "2026-10-25", "Last Name": "Nobody", "First Name": "No", "Email": "nobody@example.edu",
                 "Standard": "S01", "Mark": "M", "Kind": "Window", "Entered": ""})
    engine._write_office_rows(folder, rows)
    check("office_hours.csv is a source file", any(p.name == "office_hours.csv" for p in engine.source_files(folder)),
          True)

    gb = engine.load(folder)
    check("office-hour sittings between the Gradescope ones", [s.label for s in gb.sittings],
          ["SA1", "OH after SA1", "SA2", "OH after SA2"])
    check("office-hour sitting dates", [str(s.date) for s in gb.sittings if s.office], ["2026-10-20", "2026-11-02"])
    check("row not on the roster left out", (len(gb.office), any("nobody@example.edu is not on the roster" in w
                                                                for w in gb.warnings)), (5, True))
    check("marks after office hours", (gb.mark(e["eepsilon"], "S02"), gb.mark(e["ddelta"], "S03"),
                                       gb.mark(e["cchi"], "S04")), ("M", "R", "M"))
    check("standards at M after office hours", [gb.count_m(s.email) for s in gb.students], [3, 3, 2, 1, 1, 2])
    check("office R listed as pending", any(std == "S03" and s.email == e["ddelta"] and sit.label == "OH after SA1"
                                            for s, std, sit in gb.pending_revisions()), True)
    check("new office-hour sittings record no changes", gb.new_changes, [])
    rows, total = gb.new_m_table()
    check("reached M at each sitting, with office hours", [(sit.label, list(counts.values())) for sit, counts in rows],
          [("SA1", [3, 1, 1, None]), ("OH after SA1", [0, 1, 0, None]), ("SA2", [2, None, None, 3]),
           ("OH after SA2", [0, None, None, 1])])
    check("total row with office hours", total, {"S01": 5, "S02": 2, "S03": 1, "S04": 4})
    check("rows add up to the total", {std: sum(c[std] or 0 for _, c in rows) for std in total}, total)

    w = gb.office_warnings()
    check("five office-hour warnings", len(w), 5)
    check("second Window attempt", any("Eli Epsilon has 2 attempts of the kind “Window”, and 1 is allowed" in x
                                       for x in w), True)
    check("Window used after it ends", any("Cy Chi's attempt at S04 on Nov 2" in x and "before Oct 30" in x for x in w),
          True)
    check("Note with no note", any("Dee Delta's attempt at S03" in x and "column is blank" in x for x in w), True)
    check("Note for another standard", any("Ada Alpha's attempt at S01" in x and "column gives S03" in x for x in w),
          True)
    check("attempt at a standard already at M", any("Ada Alpha attempted S01 on Nov 3, but S01 was already at M "
                                                    "from SA1" in x for x in w), True)
    engine.save_manual(gb, {e["ddelta"]: {"Note standard": "S03"}})
    gb.manual = engine.read_manual(folder)
    check("a note typed in later clears its warning at once", len(gb.office_warnings()), 4)

    # An R fixed in office hours is a change of mark; a new attempt is not; a deleted one is.
    dee = next(i for i, r in enumerate(engine.read_office_rows(folder)) if r["Email"] == e["ddelta"])
    engine.save_office_edits(folder, {dee: {"Mark": "M", "Date": "2026-10-21"}})
    engine.add_office_attempt(gb, "2026-11-04", e["bbeta"], "S02", "R", "Window")
    gb = engine.load(folder)
    check("office-hour change recorded", [(r["Sitting"], r["Student"], r["Standard"], engine.change_text(r))
                                          for r in gb.new_changes], [("OH after SA1", "Dee Delta", "S03", "R → M")])
    check("Dee's S03 now M", (gb.mark(e["ddelta"], "S03"), gb.count_m(e["ddelta"])), ("M", 2))
    eli = next(i for i, r in enumerate(engine.read_office_rows(folder)) if r["Email"] == e["eepsilon"]
               and r["Standard"] == "S01")
    engine.save_office_edits(folder, {}, [eli])
    gb = engine.load(folder)
    check("deleted attempt recorded", [(r["Standard"], engine.change_text(r)) for r in gb.new_changes], [("S01", "N → blank")])
    check("office_hours.csv backed up", (folder / "records" / "office_hours.backup.csv").exists(), True)
    check("dates written by Excel are read", engine.to_date("11/6/2026"), engine.to_date("2026-11-06"))

    out = write_workbook(gb)
    wb = openpyxl.load_workbook(out)
    ws = wb["Office hours"]
    check("office-hours sheet", [[c.value for c in row][4:8] for row in ws.iter_rows(min_row=2, max_row=3)],
          [["S02", "M", "Window", "OH after SA1"], ["S03", "M", "Note", "OH after SA1"]])
    cells = [[c.value for c in row] for row in wb["Summary"].iter_rows()]
    total_row = next(r for r in cells if r[0] == "Total")
    check("workbook total row", total_row[1:5], [5, 2, 2, 4])
    cfg = load_config(folder)
    if tomllib is not None:
        check("course.toml with office hours reads back the same", tomllib.loads(config_to_toml(cfg))["office_hours"],
              cfg["office_hours"])


def revisions(folder):
    """An office-hour attempt at a standard the last Gradescope sitting gave R fixes that R, and does not
    count toward the limit of its kind."""
    e = EMAIL
    gb = engine.load(folder)
    cy = next(a for a in gb.office if a.email == e["cchi"])
    check("attempt at an SA2 R fixes it", (gb.revises(cy), gb.attempt_kind(cy)), ("SA2", "Fixes SA2 R"))
    ada = next(a for a in gb.office if a.email == e["aalpha"])
    check("attempt at an SA2 N is a retake", (gb.revises(ada), gb.attempt_kind(ada)), (None, "Note"))
    engine.add_office_attempt(gb, "2026-11-05", e["cchi"], "S02", "N", "Window")   # SA2 did not assess S02
    gb = engine.load(folder)
    check("one retake and one R revision are within the limit",
          any("Cy Chi has 2 attempts" in w for w in gb.office_warnings()), False)
    ws = openpyxl.load_workbook(write_workbook(gb))["Office hours"]
    check("office-hours sheet says how each attempt counts",
          [(r[0].value, r[4].value, r[8].value) for r in ws.iter_rows(min_row=2) if r[3].value == e["cchi"]],
          [(dt.datetime(2026, 11, 2), "S04", "Fixes SA2 R"), (dt.datetime(2026, 11, 5), "S02", "Retake")])


def oral_exam(folder):
    """An SA2 R changed to M on Gradescope after an office-hour attempt fixed it: changes.csv keeps the R,
    so the attempt is still a revision, and the check that S04 was already at M shows the double entry."""
    e = EMAIL
    sa2 = {"aalpha": [N, M], "bbeta": [M, M], "cchi": [None, M], "ddelta": [N, N], "eepsilon": [N, N],
           "fzeta": [M, M]}
    newer = folder / "exports" / "Standards_Assessment_2_scores (1).xlsx"
    write_export(newer, ["S01", "S04"], sa2, "2026-10-30")
    later = time.time() + 10
    os.utime(newer, (later, later))
    gb = engine.load(folder)
    check("SA2 R changed to M recorded", [(r["Student"], r["Standard"], engine.change_text(r)) for r in gb.new_changes],
          [("Cy Chi", "S04", "R → M")])
    cy = next(a for a in gb.office if a.email == e["cchi"] and a.standard == "S04")
    check("attempt still fixes the SA2 R", gb.revises(cy), "SA2")
    w = gb.office_warnings()
    check("still within the limit, and the double entry is shown",
          (any("Cy Chi has 2 attempts" in x for x in w),
           any("Cy Chi attempted S04 on Nov 2, but S04 was already at M from SA2" in x for x in w)), (False, True))


FOUR_TOML = """[course]
title = "TEST 202"
term = "Test term"
output = "Gradebook_FOUR.xlsx"
planned_standards = 2

[gradescope]
standard_pattern = 'S\\d+'

[[level]]
name = "E"
label = "Exemplary"
score = 1.0
mastered = true
revisable = false

[[level]]
name = "P"
label = "Proficient"
score = 0.75
mastered = true
revisable = false

[[level]]
name = "D"
label = "Developing"
score = 0.01
mastered = false
revisable = true

[[level]]
name = "B"
label = "Beginning"
score = 0.0
mastered = false
revisable = false

[office_hours]
label = "OH"

[[office_hours.kind]]
name = "Window"
per_student = 1
"""


def level_rules(folder):
    """The checks on a list of levels, and an older course.toml read as M, R and N."""
    good = [dict(r) for r in levels.LEGACY]
    check("the M, R and N levels are fine", levels.problems(good), [])
    check("no levels", levels.problems([]), ["No mark levels are set."])
    two = [dict(good[0]), dict(good[1], score=1.0), dict(good[2], name="m")]
    got = levels.problems(two)
    check("same score and same name found", (any("Two levels have the score 1" in x for x in got),
                                            any("Two levels are named" in x for x in got)), (True, True))
    check("five decimal places refused", any("more than 4 decimal places" in x
                                             for x in levels.problems([dict(good[0]), dict(good[1], score=0.00001)])),
          True)
    check("mastered levels first", any("have to come first" in x for x in levels.problems(
        [dict(good[1]), dict(good[0]), dict(good[2])])), True)
    check("none mastered", levels.problems([dict(good[1]), dict(good[2])]), ["No level counts as mastered."])
    check("seven levels refused", any("at most 6" in x for x in levels.problems(
        [dict(good[0], name=f"L{i}", score=i / 10) for i in range(7)])), True)
    (folder / "course.toml").write_text('[gradescope]\nM = 1.0\nR = 0.0001\nN = 0.0\n', encoding="utf-8")
    cfg = load_config(folder)
    check("older course.toml read as three levels", [(r["name"], r["score"], r["mastered"], r["revisable"])
                                                      for r in cfg["level"]],
          [("M", 1.0, True, False), ("R", 0.0001, False, True), ("N", 0.0, False, False)])
    if tomllib is not None:
        check("levels written as [[level]] read back the same", load_config_text(config_to_toml(cfg))["level"],
              cfg["level"])
    lv = levels.Levels(cfg["level"])
    check("words for M, R and N", (lv.at, lv.held, lv.pending, lv.goal, lv.status_label("R"), lv.here_label("M")),
          ("at M", "(M)", "Pending R", "M", "R pending", "M here"))


def load_config_text(text):
    return tomllib.loads(text)


def four_levels(folder):
    """A course with four levels, E and P mastered and D revisable, scored 1, 0.75, 0.01 and 0."""
    e = EMAIL
    exports = folder / "exports"
    exports.mkdir()
    (folder / "course.toml").write_text(FOUR_TOML, encoding="utf-8")
    write_roster(exports / "TestCourse-01.csv")
    E, P, D, B = 1.0, 0.75, 0.01, 0.0
    write_export(exports / "Standards_Assessment_1_scores.xlsx", ["S01", "S02"],
                 {"aalpha": [P, E], "bbeta": [D, B], "cchi": [P, D], "ddelta": [D, D], "eepsilon": [B, 0.5]},
                 "2026-10-14")
    write_export(exports / "Standards_Assessment_2_scores.xlsx", ["S01", "S02"],
                 {"aalpha": [P, E], "bbeta": [D, B], "cchi": [E, P], "ddelta": [D, B], "eepsilon": [B, B]},
                 "2026-10-30")
    write_canvas(exports / "2026-10-20T1200_Grades-TEST.csv")
    gb = engine.load(folder)
    engine.add_office_attempt(gb, "2026-11-02", e["ddelta"], "S01", "p", "Window")   # typed in lower case
    engine.add_office_attempt(gb, "2026-11-03", e["ddelta"], "S02", "D", "Window")
    gb = engine.load(folder)
    L = gb.levels
    check("four levels read", (L.names, L.mastered_names, L.revisable_names), (["E", "P", "D", "B"], ["E", "P"], ["D"]))
    check("words for four levels", (L.at, L.held, L.pending, L.goal, L.status_label("P"), L.status_label("D")),
          ("mastered", "(mastered)", "Pending D", "mastery", "At P", "D pending"))
    check("a score that is no level is reported", any("Eli Epsilon S02 = 0.5" in w for w in gb.warnings), True)
    check("standards mastered per student", [gb.count_m(s.email) for s in gb.students], [2, 0, 2, 1, 0, 0])
    check("best level kept", (gb.mark(e["cchi"], "S01"), gb.mark(e["cchi"], "S02"), gb.mark(e["ddelta"], "S01")),
          ("E", "P", "P"))
    check("a better mastered level shows; the same one is held",
          (gb.sitting_mark(e["cchi"], 1, "S01"), gb.sitting_mark(e["aalpha"], 1, "S01")), ("E", levels.HELD))
    check("standard counts", gb.standard_counts("S01"), {"E": 1, "P": 2, "D": 1, "B": 1, "Not attempted": 1})
    check("pending revisions", sorted((s.first, std, sit.label) for s, std, sit in gb.pending_revisions()),
          [("Ben", "S01", "SA2"), ("Dee", "S02", "OH")])
    fix, other = sorted((a for a in gb.office), key=lambda a: a.standard)
    check("an office-hour attempt at an SA2 D fixes it", (gb.attempt_kind(fix), gb.attempt_kind(other)),
          ("Fixes SA2 D", "Window"))
    check("a revision does not count toward the limit", any("Dee Delta has 2 attempts" in w
                                                            for w in gb.office_warnings()), False)
    rows, total = gb.new_m_table()
    check("reached mastery at each sitting", [(sit.label, counts) for sit, counts in rows] + [("Total", total)],
          [("SA1", {"S01": 2, "S02": 1}), ("SA2", {"S01": 0, "S02": 1}), ("OH", {"S01": 1, "S02": 0}),
           ("Total", {"S01": 3, "S02": 2})])
    path, stds = engine.write_canvas_upload(gb)
    with open(path, newline="", encoding="utf-8") as fh:
        up = list(csv.reader(fh))
    check("Canvas upload marks E and P complete", [r[-2:] for r in up[1:4]], [["1", "1"], ["0", "0"], ["1", "1"]])
    wb = openpyxl.load_workbook(write_workbook(gb))
    heads = [c.value for c in wb["Students"][1]]
    check("workbook headings", ("Standards mastered" in heads,
                                [c.value for c in wb["Summary"][4 + 6 + 1]][3:8]),
          (True, ["At E", "At P", "D pending", "B", "Not attempted"]))
    sa2 = [[c.value for c in r] for r in wb["SA2"].iter_rows(min_row=2, max_row=4)]
    check("SA2 sheet shows the held standard and the D column",
          ([r[4:8] for r in sa2], [c.value for c in wb["SA2"][1]][-1]),
          ([["(mastered)", "(mastered)", None, None], ["D", "B", None, "S01"], ["E", "P", "S02", None]], "D here"))
    page, _ = write_phone_view(gb)
    text = page.read_text(encoding="utf-8")
    check("phone page in four levels", ("D pending" in text, 'class="c l1"' in text, "Pending D" in text,
                                        "at M" in text), (True, True, True, False))
    try:
        from streamlit.testing.v1 import AppTest
    except ImportError:
        print("SKIP four-level dashboard: Streamlit is not installed")
        return
    os.environ["GRADEBOOK_FOLDER"] = str(folder)
    at = AppTest.from_file(str(HERE / "dashboard.py"), default_timeout=60)
    at.run()
    check("four-level dashboard runs without errors", [x.value for x in at.exception], [])
    check("four-level dashboard tabs", [t.label for t in at.tabs][:6], ["Summary", "Students", "SA1", "SA2",
                                                                         "Office hours", "Revisions"])
    check("four-level dashboard headings", any(h.value == "Students who reached mastery on each standard at each "
                                                          "sitting" for h in at.subheader), True)


def first_run(folder):
    """A folder with no course.toml opens on the setup page, and saving it writes course.toml."""
    exports = folder / "exports"
    exports.mkdir()
    write_export(exports / "Standards_Assessment_1_scores.xlsx", ["S01", "S02"],
                 {"aalpha": [M, R], "bbeta": [N, M]}, "2026-10-14")
    found, scores = engine.scan_exports(folder, r"S\d+")
    check("setup page reads the exports", (found, scores),
          ([("Standards_Assessment_1_scores.xlsx", ["S01", "S02"], [])], [1.0, 0.0001, 0.0]))
    found, _ = engine.scan_exports(folder, r"LT\d+")
    check("a pattern that finds nothing", found[0][1:], ([], ["1: S01 (1.0 pts)", "2: S02 (1.0 pts)"]))
    try:
        from streamlit.testing.v1 import AppTest
    except ImportError:
        print("SKIP first-run page: Streamlit is not installed")
        return
    os.environ["GRADEBOOK_FOLDER"] = str(folder)
    at = AppTest.from_file(str(HERE / "dashboard.py"), default_timeout=60)
    at.run()
    check("first run opens on the setup page", ([x.value for x in at.exception], [t.value for t in at.title]),
          ([], ["Set up the gradebook"]))
    check("setup page shows the scores in the export",
          any("Scores in these exports: 1, 0.0001, 0." in m.value for m in at.markdown), True)
    at.text_input[0].set_value("TEST 303")
    next(b for b in at.button if b.label == "Save").click().run()
    check("saving the setup page writes course.toml", (folder / "course.toml").exists(), True)
    cfg = load_config(folder)
    check("course.toml from the setup page", (cfg["course"]["title"], [r["name"] for r in cfg["level"]],
                                              cfg.get("office_hours")),
          ("TEST 303", ["M", "R", "N"], {"label": "OH"}))
    check("then the dashboard opens", ([x.value for x in at.exception], [t.value for t in at.title]),
          ([], ["TEST 303"]))
    gb = engine.load(folder)
    check("office hours on, with no kinds", (gb.office_on, gb.office_kinds), (True, []))


def clean_copy(folder):
    """make_clean_copy copies the tool and nothing from the course."""
    import make_clean_copy
    dest = make_clean_copy.make_copy(folder / "New course")
    names = sorted(str(p.relative_to(dest)) for p in dest.rglob("*"))
    check("clean copy holds the tool and no data",
          ([n for n in names if n.split("/")[0] in {"records", "output", "course.toml"} or n.startswith("exports/")],
           "README.md" in names, "tool/levels.py" in names, ".streamlit/config.toml" in names), ([], True, True, True))
    check("clean copy launchers can be run", os.access(dest / "Open Dashboard.command", os.X_OK)
          and os.access(dest / "tool" / "launch.sh", os.X_OK), True)
    zip_path = make_clean_copy.make_zip(dest)
    import zipfile
    with zipfile.ZipFile(zip_path) as zf:
        info = zf.getinfo("New course/Open Dashboard.command")
        check("zip keeps the Mac launchers executable", oct(info.external_attr >> 16), "0o100755")
    try:
        make_clean_copy.make_copy(dest)
        refused = False
    except SystemExit:
        refused = True
    check("clean copy refuses a folder that is not empty", refused, True)


def phone(folder):
    """The phone page: in output/, one entry per student, escaped, self-contained, rewritten only on a change."""
    e = EMAIL
    gb = engine.load(folder)
    engine.save_manual(gb, {e["cchi"]: {"Notes": "Late <SA2> & ok"}})
    gb.manual = engine.read_manual(folder)
    path, wrote = write_phone_view(gb)
    text = path.read_text(encoding="utf-8")
    check("phone page written to output/", (path.parent.name, path.name, wrote),
          ("output", "Gradebook_TEST_phone.html", True))
    check("phone page tabs are Summary, Revisions, Students", re.findall(r'<nav>.*?</nav>', text)[0],
          '<nav><a href="#summary">Summary</a><a href="#revisions">Revisions</a><a href="#students">Students</a></nav>')
    # The tab shown without a #target is the last section, which the CSS hides when another one is the target.
    check("phone page opens on Summary", (re.findall(r'<section id="(\w+)"', text)[-1],
                                         "#summary{display:block}" in text, 'start[1] : "summary"' in text),
          ("summary", True, True))
    check("phone page Summary tiles link to Students and Revisions",
          re.findall(r'<a class="tile go[^"]*" href="(#\w+)"', text), ["#students", "#revisions"])
    cards = re.findall(r'<details class="st" id="(\w+)"', text)
    links = re.findall(r'<a class="who" href="#students" data-card="(\w+)"', text)
    check("phone page names on Revisions open a student's card",
          (len(links), len(set(cards)) == len(cards), set(links) <= set(cards)),
          (len(gb.pending_revisions()) + len(gb.office), True, True))
    check("phone page has one entry per student", text.count('<details class="st"'), len(gb.students))
    check("phone page standards at M", [int(x) for x in re.findall(r'data-m="(\d+)"', text)],
          [gb.count_m(s.email) for s in gb.students])
    check("phone page lists every pending R", text.count('class="pr"'), len(gb.pending_revisions()))
    check("phone page lists every office-hour attempt", text.count('class="oh"'), len(gb.office))
    check("phone page shows the notes, escaped", ("Late &lt;SA2&gt; &amp; ok" in text, "<SA2>" in text), (True, False))
    check("phone page loads nothing from outside the file",
          re.findall(r'(?:src|href|action)="(?!#|mailto:)[^"]*"|url\(|@import|<link|<iframe|<img', text), [])
    mtime = path.stat().st_mtime_ns
    _, wrote = write_phone_view(engine.load(folder))
    check("phone page not rewritten when nothing changed", (wrote, path.stat().st_mtime_ns), (False, mtime))
    engine.save_manual(gb, {e["cchi"]: {"Notes": "updated"}})
    gb.manual = engine.read_manual(folder)
    _, wrote = write_phone_view(gb)
    check("phone page rewritten after a saved entry", (wrote, "updated" in path.read_text(encoding="utf-8")),
          (True, True))
    check("no temporary file left in output/", sorted(p.name for p in path.parent.iterdir() if p.suffix == ".tmp"), [])


if __name__ == "__main__":
    main()
