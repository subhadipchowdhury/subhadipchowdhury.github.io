"""Reading and writing course.toml, the settings of a course folder."""

from __future__ import annotations

import datetime as dt
from pathlib import Path

from levels import level_rows

try:
    import tomllib
except ModuleNotFoundError:  # Python older than 3.11
    tomllib = None

CONFIG_FILE = "course.toml"

DEFAULT_MANUAL = [
    {"name": "Homework %", "type": "percent"},
    {"name": "Notes", "type": "text"},
]


def default_config():
    return {
        "course": {"title": "Course", "term": "", "output": "Gradebook.xlsx", "planned_standards": 0},
        "gradescope": {"standard_pattern": r"S\d+"},
        "level": [],
        "standards": {},
        "groups": {},
        "sittings": {},
        "grading": {"homework_column": "Homework %"},
        "canvas": {"homework_pattern": r"^Homework", "homework_divisor": 0.95},
        "grade": [],
        "manual": [dict(c) for c in DEFAULT_MANUAL],
    }


def config_exists(folder: Path):
    return (Path(folder) / CONFIG_FILE).exists()


def load_config(folder: Path):
    """Read course.toml, filling in anything it leaves out. The mark levels are always in cfg["level"],
    also when course.toml gives them the older way, as M, R and N under [gradescope]."""
    cfg = default_config()
    path = Path(folder) / CONFIG_FILE
    if path.exists():
        if tomllib is None:
            raise RuntimeError("Reading course.toml needs Python 3.11 or later.")
        with open(path, "rb") as fh:
            user = tomllib.load(fh)
        for key, value in user.items():
            if isinstance(value, dict) and isinstance(cfg.get(key), dict):
                cfg[key].update(value)
            else:
                cfg[key] = value
    cfg["level"] = level_rows(cfg)
    for mark in ("M", "R", "N"):
        cfg["gradescope"].pop(mark, None)
    return cfg


def _toml_str(s):
    return '"' + str(s).replace("\\", "\\\\").replace('"', '\\"') + '"'


def _toml_value(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return repr(v)
    if isinstance(v, dt.date):
        return v.isoformat()  # a TOML date, without quotes
    if isinstance(v, (list, tuple)):
        return "[" + ", ".join(_toml_value(x) for x in v) + "]"
    return _toml_str(v)


def config_to_toml(cfg):
    """The configuration in the layout of course.toml, comments included."""
    c, g = cfg["course"], cfg["gradescope"]
    pattern = g.get("standard_pattern", r"S\d+")
    out = [
        "# Settings for the mastery gradebook of this course.",
        "# The tool reads this file every time it runs. The Setup tab of the dashboard rewrites it.",
        "",
        "[course]",
        f"title = {_toml_str(c.get('title', ''))}",
        f"term = {_toml_str(c.get('term', ''))}",
        "# The generated workbook, written to output/. Every build replaces it, so never edit it.",
        f"output = {_toml_str(c.get('output', 'Gradebook.xlsx'))}",
        "# The number of standards you expect by the end of the quarter. Change it if the plan changes.",
        f"planned_standards = {int(c.get('planned_standards', 0))}",
        "",
        "[gradescope]",
        '# Picks the standard out of a Gradescope question title, such as "1: S01 (1.0 pts)".',
        f"standard_pattern = '{pattern}'",
        "",
        "# The mark levels, best first. score is the Gradescope score that stands for the level, with at most",
        "# 4 decimal places. The levels with mastered = true come first and count as mastered. A level with",
        "# revisable = true is listed on the Revisions tab until a later mark replaces it.",
    ]
    for lv in cfg.get("level", []):
        out += ["", "[[level]]"]
        out += [f"{k} = {_toml_value(float(lv[k]) if k == 'score' else lv[k])}"
                for k in ("name", "label", "score", "mastered", "revisable") if k in lv]
    out += [
        "",
        "[standards]",
        "# Optional descriptions. A standard that appears in an export is added even if it is not listed here.",
    ]
    out += [f"{k} = {_toml_str(v)}" for k, v in cfg.get("standards", {}).items()]
    out += [
        "",
        "[groups]",
        '# Optional named groups of standards, for grade rules such as "at least 5 core standards".',
        '# Example: core = ["P01", "P03", "P05"]',
    ]
    out += [f"{k} = {_toml_value(list(v))}" for k, v in cfg.get("groups", {}).items()]
    if cfg.get("sittings"):
        out += ["", "[sittings]", "# Short labels for sittings, replacing the ones made from the export's name."]
        out += [f"{_toml_str(k)} = {_toml_str(v)}" for k, v in cfg["sittings"].items()]
    cv = cfg.get("canvas", {})
    out += [
        "",
        "[canvas]",
        "# Homework is read from the newest Canvas gradebook export in exports/, from the assignments",
        "# whose names match homework_pattern. The score is the points earned on the graded ones over",
        "# homework_divisor times their points possible, capped at 100%.",
        f"homework_pattern = '{cv.get('homework_pattern', '^Homework')}'",
        f"homework_divisor = {_toml_value(float(cv.get('homework_divisor', 0.95)))}",
        "",
        "[grading]",
        "# Without a Canvas export, the homework score is read from this manual column instead.",
        f"homework_column = {_toml_str(cfg.get('grading', {}).get('homework_column', 'Homework %'))}",
        "",
        "# The base-grade checklist. The base grade is the first row whose requirements are all met.",
        '# "standards" counts standards at M, "homework" is a fraction, and a group name counts that group.',
    ]
    for row in cfg.get("grade", []):
        out += ["", "[[grade]]"]
        out += [f"{k} = {_toml_value(v)}" for k, v in row.items()]
    out += [
        "",
        "# The columns you fill in by hand. They are kept in records/manual.csv.",
        "# Types are percent, integer, yes/no, choice (with choices) and text.",
    ]
    for col in cfg.get("manual", []):
        out += ["", "[[manual]]"]
        out += [f"{k} = {_toml_value(v)}" for k, v in col.items()]
    oh = cfg.get("office_hours")
    if oh:
        out += [
            "",
            "[office_hours]",
            "# Attempts in office hours, entered on the Office hours tab and kept in records/office_hours.csv.",
            "# The attempts between two Gradescope sittings count as one more sitting, with this label.",
        ]
        out += [f"{k} = {_toml_value(v)}" for k, v in oh.items() if k != "kind"]
        out += [
            "",
            "# An attempt at a standard the last standards assessment gave R is a revision of that R and does not count",
            "# toward per_student.",
            "# The kinds of attempt. per_student is how many attempts of that kind each student may make,",
            "# before is the first date on which that kind can no longer be used, and note_column names the",
            "# manual column that must hold the standard before a student can use that kind.",
        ]
        for kind in oh.get("kind", []):
            out += ["", "[[office_hours.kind]]"]
            out += [f"{k} = {_toml_value(v)}" for k, v in kind.items()]
    return "\n".join(out) + "\n"


def save_config(folder: Path, cfg):
    (Path(folder) / CONFIG_FILE).write_text(config_to_toml(cfg), encoding="utf-8")
