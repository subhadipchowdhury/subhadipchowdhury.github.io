"""The phone page of the gradebook, one read-only HTML file in output/ to open on a phone through OneDrive.

The dashboard rewrites it whenever it reads the folder or saves an entry, and build.py writes it too. It is
written only when its content changes, so OneDrive syncs it only then. The file holds its own styles and one
short script, and its Content-Security-Policy forbids it to load anything from the internet. Without the
script it still works. The script adds the search box, opens a student's card from a name on the Revisions
tab, and switches tabs without adding to the browser's history, so that the back button leaves the page.
Uses only the standard library.
"""

from __future__ import annotations

import datetime as dt
import html
import os
from string import Template

from engine import HELD, day, source_files
from files import MANUAL_FILE, records_dir
from style import ACCENT, LEVEL_SLOTS, NOT_ATTEMPTED_COLOUR

SUFFIX = "_phone.html"
GRADE_CLASS = {"A": "gm", "B": "gm", "C": "gr", "D": "gr", "F": "gn"}
ARROW = ' <span class="arr">→</span> '


def esc(x):
    return html.escape(str(x), quote=True)


def phone_path(gb):
    """output/<workbook name>_phone.html, beside the workbook."""
    wb = gb.workbook_path
    return wb.with_name(wb.stem + SUFFIX)


def updated_at(gb):
    """The time of the newest file the page is built from. The page shows it instead of the time it was
    written, so that it changes only when those files do."""
    paths = list(source_files(gb.folder)) + [records_dir(gb.folder) / MANUAL_FILE]
    times = [p.stat().st_mtime for p in paths if p.exists()]
    return dt.datetime.fromtimestamp(max(times)) if times else None


def write_phone_view(gb):
    """Write the page if its content has changed. Returns the path and True if the file was written."""
    path = phone_path(gb)
    text = render(gb)
    try:
        if path.read_text(encoding="utf-8") == text:
            return path, False
    except (OSError, UnicodeDecodeError):
        pass
    path.parent.mkdir(exist_ok=True)
    tmp = path.with_name("." + path.name + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)  # one change for OneDrive to sync, never a half-written file
    return path, True


# ----------------------------------------------------------------------------- small pieces

def mark_class(gb, mark):
    """The CSS class of a mark: l0 to l5 by the level's colour slot, h for held, x for none."""
    if mark == HELD:
        return "h"
    slot = gb.levels.slot(mark) if mark else None
    return "x" if slot is None else f"l{slot}"


def bar_class(gb, status):
    slot = gb.levels.slot(status)
    return "bx" if slot is None else f"b{slot}"


def chip(gb, std, mark):
    return f'<span class="c {mark_class(gb, mark)}"><small>{esc(std)}</small>{esc(mark or "–")}</span>'


def pill(gb, text, mark=None):
    return f'<span class="s {mark_class(gb, mark)}">{esc(text)}</span>'


def manual_text(gb, email, name):
    v = gb.manual_value(email, name)
    if v is None:
        return ""
    kind = gb.manual_type(name)
    if kind == "percent":
        return f"{v:.0%}"
    if kind == "yes/no":
        return "yes" if v else ""
    return str(v)


def short_date(text):
    try:
        return day(dt.datetime.strptime(text, "%Y-%m-%d %H:%M"))
    except (TypeError, ValueError):
        return text or ""


def tile(label, value, extra="", cls="", href=None):
    """A number in a box. With href, the box is a link to that tab."""
    inner = f'<span class="lab">{esc(label)}</span><span class="val">{value}</span>{extra}'
    if href:
        return f'<a class="tile go {cls}" href="{href}">{inner}</a>'
    return f'<div class="tile {cls}">{inner}</div>'


def card_ids(gb):
    """The id of each student's card on the Students tab, by email."""
    return {s.email: f"st{k}" for k, s in enumerate(gb.students)}


def card_link(cid, text):
    """A name that opens the student's card. Without the script it only switches to the Students tab."""
    return f'<a class="who" href="#students" data-card="{cid}">{esc(text)}</a>'


def steps(gb, email, std):
    """The marks of one standard sitting by sitting, as on the dashboard's student card."""
    out = []
    for k, sit in enumerate(gb.sittings):
        if std not in sit.standards or gb.sitting_mark(email, k, std) == HELD:
            continue
        m = sit.marks.get(email, {}).get(std)
        if m:
            out.append(pill(gb, f"{sit.label} {m}", m))
        elif sit.office:
            continue  # office hours list only the standards a student attempted there
        elif sit.status.get(email, "") != "Graded":
            out.append(pill(gb, f"{sit.label} absent"))
        else:
            out.append(pill(gb, f"{sit.label} not attempted"))
    return out


# ----------------------------------------------------------------------------- students

def student(gb, s, cid):
    e = s.email
    marks = {std: gb.mark(e, std) for std in gb.standards}
    at_m = gb.count_m(e)
    top = max(gb.planned, len(gb.standards), 1)
    hw = gb.homework_score(e)
    grade = gb.base_grade(e)
    pending = sum(1 for m in marks.values() if gb.levels.revisable(m))
    search = f"{s.first} {s.last} {s.last}, {s.first} {e}".lower()

    head = (f'<summary><div class="row1"><span class="nm">{esc(s.last)}, {esc(s.first)}</span>'
            f'<span class="cnt"><b>{at_m}</b> of {top} {gb.levels.at}</span><span class="chev">›</span></div>'
            f'<div class="chips">{"".join(chip(gb, std, m) for std, m in marks.items())}</div></summary>')

    note = ""
    if grade is None and gb.planned and gb.assessed_count < gb.planned:
        note = f'<span class="note">once all {gb.planned} standards are assessed</span>'
    tiles = (tile(f"Standards {gb.levels.at}", f"{at_m}<small> of {top}</small>",
                  f'<span class="prog"><i style="width:{100 * at_m / top:.1f}%"></i></span>')
             + tile("Homework", "–" if hw is None else f"{hw:.0%}")
             + tile(gb.levels.pending, str(pending))
             + tile("Base grade", esc(grade or "–"), note, GRADE_CLASS.get(grade, "")))

    rows = []
    for std in gb.standards:
        st_steps = steps(gb, e, std)
        mark = marks[std]
        rows.append(f'<div class="std"><div class="sh"><b>{esc(std)}</b><span class="desc">{esc(gb.describe(std))}'
                    f'</span><span class="now {mark_class(gb, mark)}">{esc(mark or "–")}</span></div>'
                    f'<div class="steps">{ARROW.join(st_steps) if st_steps else pill(gb, "not assessed yet")}</div></div>')
    parts = ['<div class="card"><div class="tiles">', tiles, '</div><h3>By standard</h3>', "".join(rows)]

    mine = [a for a in gb.office if a.email == e]
    if mine:
        items = "".join(f'<li>{pill(gb, f"{a.standard} {a.mark}", a.mark)} {day(a.date)}'
                        f'{", " + esc(gb.attempt_kind(a)) if gb.attempt_kind(a) else ""}</li>' for a in mine)
        parts.append(f'<h3>Office hours</h3><ul class="plain">{items}</ul>')

    entries = [(name, manual_text(gb, e, name)) for name in gb.manual_columns()]
    entries = "".join(f"<dt>{esc(n)}</dt><dd>{esc(v)}</dd>" for n, v in entries if v)
    parts.append("<h3>Entered by hand</h3>" + (f"<dl>{entries}</dl>" if entries else '<p class="muted">Nothing yet.</p>'))

    changes = [r for r in gb.changes if r.get("Email") == e]
    if changes:
        items = "".join(f'<li>{esc(r["Sitting"])} {esc(r["Standard"])} {esc(r["From"])} → {esc(r["To"])} '
                        f'<span class="muted">export of {esc(short_date(r["Export downloaded"]))}</span></li>'
                        for r in reversed(changes))
        parts.append(f'<h3>Changes recorded</h3><ul class="plain">{items}</ul>')

    parts.append(f'<a class="mail" href="mailto:{esc(e)}">{esc(e)}</a></div>')
    return f'<details class="st" id="{cid}" data-q="{esc(search)}" data-m="{at_m}">{head}{"".join(parts)}</details>'


# ----------------------------------------------------------------------------- summary

def median_chart(gb):
    rows = [(sit.label, gb.summary(through=k)) for k, sit in enumerate(gb.sittings)]
    top = max(gb.planned, len(gb.standards), 1)
    W, H, L, R, T, B = 320, 196, 24, 8, 18, 40
    n = len(rows)
    xs = [L + (W - L - R) * (i + 0.5) / n for i in range(n)]

    def y(v):
        return T + (H - T - B) * (1 - v / top)

    step = 1 if top <= 6 else 2 if top <= 12 else 5
    parts = []
    for v in range(0, top + 1, step):
        parts.append(f'<line class="grid" x1="{L}" x2="{W - R}" y1="{y(v):.1f}" y2="{y(v):.1f}"/>'
                     f'<text x="{L - 6}" y="{y(v) + 4:.1f}" text-anchor="end">{v}</text>')
    if n > 1:
        upper = [f"{xs[i]:.1f},{y(r['q3']):.1f}" for i, (_, r) in enumerate(rows)]
        lower = [f"{xs[i]:.1f},{y(r['q1']):.1f}" for i, (_, r) in reversed(list(enumerate(rows)))]
        parts.append(f'<polygon class="band" points="{" ".join(upper + lower)}"/>')
        line = " ".join(f"{xs[i]:.1f},{y(r['median']):.1f}" for i, (_, r) in enumerate(rows))
        parts.append(f'<polyline class="line" points="{line}"/>')
    elif n == 1:
        r = rows[0][1]
        parts.append(f'<rect class="band" x="{xs[0] - 10:.1f}" y="{y(r["q3"]):.1f}" width="20" '
                     f'height="{max(y(r["q1"]) - y(r["q3"]), 0):.1f}"/>')
    for i, (label, r) in enumerate(rows):
        cx, cy = xs[i], y(r["median"])
        parts.append(f'<circle class="dot" cx="{cx:.1f}" cy="{cy:.1f}" r="5"/>'
                     f'<text class="v" x="{cx:.1f}" y="{cy - 9:.1f}" text-anchor="middle">{r["median"]:g}</text>')
        first, _, rest = label.partition(" after ")
        lines = [first, "after " + rest] if rest else [label]
        spans = "".join(f'<tspan x="{cx:.1f}" dy="{0 if j == 0 else 13}">{esc(t)}</tspan>' for j, t in enumerate(lines))
        parts.append(f'<text x="{cx:.1f}" y="{H - B + 18}" text-anchor="middle">{spans}</text>')
    return (f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="Median standards {gb.levels.at} after each sitting">'
            f'{"".join(parts)}</svg>')


def summary(gb):
    s = gb.summary()
    n = len(gb.students)
    median = "–" if s["median"] is None else f'{s["median"]:g}'
    mean = "" if s["mean"] is None else f'<span class="note">mean {s["mean"]:.2f}</span>'
    assessed = f"{gb.assessed_count}<small> of {gb.planned}</small>" if gb.planned else str(gb.assessed_count)
    out = ['<div class="panel"><div class="tiles">', tile("Students", str(n), href="#students"),
           tile("Standards assessed", assessed), tile(f"Median {gb.levels.at}", median, mean),
           tile("Pending revisions", str(len(gb.pending_revisions())), href="#revisions"), "</div></div>"]
    if not gb.sittings:
        out.append('<div class="panel"><p>No Gradescope exports yet.</p></div>')
        return "".join(out)

    legend = "".join(f'<span><i class="{bar_class(gb, k)}"></i>{esc(gb.levels.status_label(k))}</span>'
                     for k in gb.levels.statuses)
    bars = []
    for std in gb.standards:
        c = gb.standard_counts(std)
        segs = ""
        for k in gb.levels.statuses:
            if c[k]:
                w = 100 * c[k] / n
                segs += f'<i class="{bar_class(gb, k)}" style="width:{w:.2f}%">{c[k] if w >= 8 else ""}</i>'
        bars.append(f'<div class="brow"><b>{esc(std)}</b><div class="bar">{segs}</div>'
                    f'<span class="bv">{sum(c[m] for m in gb.levels.mastered_names)} {gb.levels.at}</span></div>')
    out.append(f'<div class="panel"><h2>Where each standard stands</h2><div class="legend">{legend}</div>'
               f'{"".join(bars)}</div>')

    top = max(gb.planned, len(gb.standards))
    counts = [gb.count_m(x.email) for x in gb.students]
    hist = [counts.count(k) for k in range(top + 1)]
    most = max(hist) or 1
    rows = "".join(f'<div class="brow"><b>{k}</b><div class="bar"><i class="ba" style="width:{100 * h / most:.2f}%">'
                   f'</i></div><span class="bv">{h}</span></div>' for k, h in enumerate(hist))
    out.append(f'<div class="panel"><h2>Students by number of standards {gb.levels.at}</h2>'
               f'<div class="hhead"><span>{gb.levels.at[0].upper()}{gb.levels.at[1:]}</span><span></span><span>Students</span></div>' + rows + "</div>")

    out.append(f'<div class="panel"><h2>Median standards {gb.levels.at} after each sitting</h2>' + median_chart(gb)
               + '<p class="cap">The band runs from the lower to the upper quartile. Each sitting counts the standards '
               f"{gb.levels.at} from that sitting and the ones before it.</p></div>")

    table_rows, total = gb.new_m_table()
    head = "".join(f"<th>{esc(std)}</th>" for std in gb.standards)
    body = ""
    for sit, c in table_rows:
        cells = "".join(f"<td>{'' if c[std] is None else c[std]}</td>" for std in gb.standards)
        body += f"<tr><td>{esc(sit.label)}</td>{cells}</tr>"
    body += '<tr class="total"><td>Total</td>' + "".join(f"<td>{total[std]}</td>" for std in gb.standards) + "</tr>"
    out.append(f'<div class="panel"><h2>Students who reached {gb.levels.goal} on each standard at each sitting</h2>'
               f'<div class="tw"><table><tr><th>Sitting</th>{head}</tr>{body}</table></div>'
               '<p class="cap">A blank means the standard was not on that sitting. The total is the number of '
               f"students {gb.levels.at} now.</p></div>")
    return "".join(out)


# ----------------------------------------------------------------------------- revisions

def revisions(gb):
    ids = card_ids(gb)
    by_std = {}
    for s, std, sit in gb.pending_revisions():
        by_std.setdefault(std, []).append((s, sit))
    r = gb.levels.revisable_names
    at_r = f"at {r[0]}" if len(r) == 1 else "to revise"
    out = []
    for std in gb.standards:
        people = sorted(by_std.get(std, []), key=lambda p: (p[0].last.lower(), p[0].first.lower()))
        if not people:
            continue
        items = "".join(f'<li class="pr">{card_link(ids[p.email], f"{p.last}, {p.first}")}{pill(gb, f"{sit.label} {gb.mark(p.email, std)}", gb.mark(p.email, std))}'
                        "</li>" for p, sit in people)
        desc = f"{esc(gb.describe(std))}, " if gb.describe(std) else ""
        out.append(f'<div class="panel"><h2>{esc(std)} <span class="muted">{desc}{len(people)} '
                   f'student{"s" if len(people) != 1 else ""} {at_r}</span></h2><ul class="names">{items}</ul></div>')
    if not out:
        out.append('<div class="panel"><p>No pending revisions.</p></div>')

    if gb.office_on:
        name = {s.email: f"{s.last}, {s.first}" for s in gb.students}
        used = []
        for kind in gb.office_kinds:
            k = len({a.email for a in gb.office if a.kind == kind and not gb.revises(a)})
            used.append(f"{esc(kind)} used by {k} student{'s' if k != 1 else ''}.")
        attempts = sorted(gb.office, key=lambda a: (a.date, a.row), reverse=True)
        items = "".join(f'<li class="oh">{card_link(ids[a.email], name[a.email])}{pill(gb, f"{a.standard} {a.mark}", a.mark)}'
                        f'<span class="muted">{day(a.date)}{", " + esc(gb.attempt_kind(a)) if gb.attempt_kind(a) else ""}</span></li>'
                        for a in attempts)
        out.append('<div class="panel"><h2>Office-hour attempts</h2>'
                   + (f'<p class="cap top">{" ".join(used)}</p>' if used else "")
                   + (f'<ul class="names">{items}</ul>' if items else '<p class="muted">No attempts yet.</p>')
                   + "</div>")
    return "".join(out)


# ----------------------------------------------------------------------------- page

def render(gb):
    at = updated_at(gb)
    stamp = f"Updated {day(at)}, {at:%H:%M}" if at else ""
    course = gb.cfg["course"]
    n = len(gb.students)
    ids = card_ids(gb)
    sub = " · ".join(esc(x) for x in (course.get("term", ""), stamp) if x)
    body = (
        f'<header><div class="t1">{esc(course.get("title") or "Mastery gradebook")}</div><div class="t2">{sub}</div>'
        "</header>"
        '<nav><a href="#summary">Summary</a><a href="#revisions">Revisions</a><a href="#students">Students</a></nav>'
        "<main>"
        # Summary, the tab the page opens on, comes last, so that the CSS can hide it when another section is
        # the target.
        f'<section id="revisions">{revisions(gb)}</section>'
        '<section id="students"><div class="search"><input id="q" type="search" placeholder="Find a student" '
        'autocomplete="off" hidden></div>'
        f'<p class="hint">{n} students. Tap a name for the full record. A dash means not attempted.</p>'
        + "".join(student(gb, s, ids[s.email]) for s in gb.students)
        + '<p id="none" class="hint" hidden>No student matches.</p></section>'
        f'<section id="summary">{summary(gb)}</section></main>'
        f"<footer>{stamp}{'. ' if stamp else ''}The file in OneDrive is rewritten whenever the gradebook's files "
        "change, but a downloaded copy is not, so download it again for newer marks. Nothing on this page can "
        "change a mark.</footer>"
    )
    light = "".join(f"--l{i}-bg:{c['tint']};--l{i}-fg:#0b0b0b;" for i, c in enumerate(LEVEL_SLOTS))
    dark = "".join(f"--l{i}-bg:{c['dark'][0]};--l{i}-fg:{c['dark'][1]};" for i, c in enumerate(LEVEL_SLOTS))
    cells = "".join(f".l{i}{{background:var(--l{i}-bg);color:var(--l{i}-fg)}}" for i in range(len(LEVEL_SLOTS)))
    bars = "".join(f".b{i}{{background:{c['bar']};color:{c['bar_text']}}}" for i, c in enumerate(LEVEL_SLOTS))
    css = CSS.substitute(light_levels=light, dark_levels=dark, level_cells=cells, level_bars=bars,
                         c_good=LEVEL_SLOTS[1]["bar"], c_bad=LEVEL_SLOTS[5]["bar"], c_x=NOT_ATTEMPTED_COLOUR,
                         accent_light=ACCENT["light"], accent_dark=ACCENT["dark"])
    return PAGE.substitute(title=esc(gb.title or "Mastery gradebook"), css=css, body=body, js=JS)


PAGE = Template("""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="color-scheme" content="light dark">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'">
<title>$title</title>
<style>$css</style>
</head>
<body>
$body
<script>$js</script>
</body>
</html>
""")

# The colours of subhadipchowdhury.github.io, maroon on white and teal on charcoal, as in .streamlit/config.toml.
CSS = Template("""
:root{--bg:#ffffff;--text:#333333;--muted:#666666;--primary:#800000;--surface:#f4f4f4;--card:#ffffff;
--border:#d6dbdd;--bar:#800000;--bartext:#ffffff;--accent:${accent_light};
${light_levels}
--h-bg:#ecf7ec;--h-fg:#52514e;--x-bg:#e9e8e4;--x-fg:#52514e}
@media (prefers-color-scheme:dark){:root{--bg:#232323;--text:#e4e4e4;--muted:#a9a9a9;--primary:#3eb1c8;
--surface:#2d2d2d;--card:#232323;--border:#3d3d3d;--bar:#151515;--bartext:#3eb1c8;--accent:${accent_dark};
${dark_levels}
--h-bg:#253825;--h-fg:#b9cdb9;--x-bg:#3a3a3a;--x-fg:#b8b8b8}}
*{box-sizing:border-box}
[hidden]{display:none!important}
body{margin:0 auto;max-width:640px;background:var(--bg);color:var(--text);
font:16px/1.4 system-ui,-apple-system,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;-webkit-text-size-adjust:100%}
header{background:var(--bar);color:var(--bartext)}
.t1{padding:10px 14px 0;font-weight:700;font-size:16px}
.t2{padding:1px 14px 2px;font-size:12px;opacity:.85}
nav{position:sticky;top:0;z-index:5;display:flex;background:var(--bar);color:var(--bartext)}
nav a{flex:1;text-align:center;padding:9px 0 7px;color:inherit;text-decoration:none;font-weight:600;font-size:15px;
opacity:.7;border-bottom:3px solid transparent}
nav a.on{opacity:1;border-bottom-color:currentColor}
html:not([data-tab]) body:not(:has(main>section:target)) nav a[href="#summary"],
html:not([data-tab]) body:has(#summary:target) nav a[href="#summary"],
html:not([data-tab]) body:has(#revisions:target) nav a[href="#revisions"],
html:not([data-tab]) body:has(#students:target) nav a[href="#students"]
{opacity:1;border-bottom-color:currentColor}
main>section{display:none}
main>section:target{display:block}
#summary{display:block}
main>section:target~#summary{display:none}
html[data-tab] main>section{display:none!important}
html[data-tab=summary] #summary,html[data-tab=revisions] #revisions,html[data-tab=students] #students
{display:block!important}
section{scroll-margin-top:100vh;padding-bottom:6px}
details.st{scroll-margin-top:40px}
.search{padding:12px 14px 0}
input[type=search]{width:100%;font-size:16px;padding:10px 12px;border:1px solid var(--border);border-radius:10px;
background:var(--card);color:var(--text)}
.hint{margin:8px 14px;font-size:13px;color:var(--muted)}
details.st{border-bottom:1px solid var(--border)}
details.st>summary{list-style:none;padding:10px 14px;cursor:pointer}
details.st>summary::-webkit-details-marker{display:none}
details.st[open]>summary,details.st[open]>.card{background:var(--surface)}
.row1{display:flex;align-items:baseline;gap:8px}
.nm{flex:1;font-weight:600}
.cnt{font-size:13px;color:var(--muted);white-space:nowrap}
.cnt b{font-size:18px;color:var(--primary)}
.chev{display:inline-block;width:12px;color:var(--muted);font-size:20px;line-height:1;transition:transform .15s}
details[open] .chev{transform:rotate(90deg)}
.chips{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px}
.c{display:inline-flex;flex-direction:column;align-items:center;justify-content:center;min-width:38px;height:36px;
border-radius:7px;font-weight:700;font-size:15px;line-height:1}
.c small{font-size:9px;font-weight:600;opacity:.7;margin-bottom:3px}
${level_cells}
.h{background:var(--h-bg);color:var(--h-fg)}
.x{background:var(--x-bg);color:var(--x-fg)}
.card{padding:2px 14px 16px}
.card h3{margin:16px 0 4px;font-size:12px;letter-spacing:.06em;text-transform:uppercase;color:var(--muted)}
.tiles{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:4px}
.tile{background:var(--card);border:1px solid var(--border);border-radius:10px;padding:8px 10px}
a.tile{display:block;color:inherit;text-decoration:none}
a.tile .lab::after{content:"›";float:right;font-size:18px;line-height:14px;color:var(--primary)}
.lab{display:block;font-size:12px;color:var(--muted)}
.val{display:block;font-size:22px;font-weight:700}
.val small{font-size:14px;font-weight:500;color:var(--muted)}
.note{display:block;font-size:11px;color:var(--muted)}
.prog{display:block;height:6px;border-radius:3px;background:var(--x-bg);margin-top:5px;overflow:hidden}
.prog i{display:block;height:100%;background:var(--primary)}
.gm .val{color:${c_good}}.gr .val{color:#c98a00}.gn .val{color:${c_bad}}
.std{padding:8px 0;border-top:1px solid var(--border)}
.card h3+.std{border-top:0}
.sh{display:flex;align-items:center;gap:8px}
.desc{flex:1;font-size:13px;color:var(--muted)}
.now{min-width:30px;padding:3px 0;border-radius:6px;text-align:center;font-weight:700}
.steps{margin-top:4px;line-height:2}
.s{display:inline-block;padding:0 8px;border-radius:999px;font-size:13px;font-weight:600;white-space:nowrap;line-height:1.7}
.arr{color:var(--muted);margin:0 1px}
ul.plain,ul.names{list-style:none;margin:0;padding:0}
ul.plain li{padding:4px 0;font-size:14px}
ul.names li{display:flex;align-items:center;gap:8px;padding:7px 0;border-top:1px solid var(--border);font-size:15px}
ul.names li:first-child{border-top:0}
ul.names li>:first-child{flex:1}
a.who{color:var(--primary);text-decoration:none}
dl{margin:4px 0 0;display:grid;grid-template-columns:auto 1fr;gap:4px 12px;font-size:14px}
dt{color:var(--muted)}
dd{margin:0;white-space:pre-line}
.mail{display:inline-block;margin-top:14px;font-size:14px;color:var(--primary)}
.muted{color:var(--muted);font-weight:400;font-size:13px}
.panel{background:var(--surface);border-radius:12px;padding:12px 14px;margin:12px}
.panel h2{margin:0 0 8px;font-size:15px}
.panel p{margin:0}
.legend{display:flex;flex-wrap:wrap;gap:4px 12px;font-size:12px;color:var(--muted);margin-bottom:4px}
.legend i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:4px;vertical-align:-1px}
.brow,.hhead{display:grid;grid-template-columns:34px 1fr 62px;align-items:center;gap:8px}
.brow{margin:7px 0;font-size:14px}
.hhead{font-size:11px;color:var(--muted)}
.hhead span:last-child,.bv{text-align:right}
.bv{color:var(--muted);font-size:13px}
.bar{display:flex;height:22px;border-radius:5px;overflow:hidden;background:var(--x-bg)}
.bar i{display:flex;align-items:center;justify-content:center;font-style:normal;font-size:12px;font-weight:700;
border-right:2px solid var(--surface)}
.bar i:last-child{border-right:0}
${level_bars}
.bx{background:${c_x};color:#0b0b0b}.ba{background:var(--accent)}
svg{display:block;width:100%;height:auto}
svg text{fill:var(--muted);font-size:11px;font-family:inherit}
svg .grid{stroke:var(--border);stroke-width:1}
svg .band{fill:var(--accent);opacity:.16}
svg .line{fill:none;stroke:var(--accent);stroke-width:2.5}
svg .dot{fill:var(--accent);stroke:var(--surface);stroke-width:2}
svg .v{fill:var(--text);font-weight:700;font-size:12px}
.tw{overflow-x:auto}
table{border-collapse:collapse;width:100%;font-size:13px}
th,td{padding:6px 2px;text-align:center;border-bottom:1px solid var(--border);white-space:nowrap}
th{font-size:12px;color:var(--muted);font-weight:600}
th:first-child,td:first-child{text-align:left}
td:first-child{white-space:normal}
tr.total td{font-weight:700;border-bottom:0}
.cap{font-size:12px;color:var(--muted);margin-top:8px!important}
.cap.top{margin:0 0 4px!important}
footer{padding:16px 14px 28px;font-size:12px;color:var(--muted)}
""")

JS = """
(function () {
  var q = document.getElementById("q"), none = document.getElementById("none");
  var rows = Array.prototype.slice.call(document.querySelectorAll("details.st"));
  function filter() {
    var v = q.value.trim().toLowerCase(), n = 0;
    rows.forEach(function (d) {
      var ok = !v || d.getAttribute("data-q").indexOf(v) >= 0;
      d.hidden = !ok;
      if (ok) n++;
    });
    none.hidden = n > 0;
  }
  if (q) {
    q.hidden = false;
    q.addEventListener("input", filter);
  }
  // The tab shown is named in data-tab on <html> and the address never changes, so switching tabs adds
  // nothing to the browser's history and the back button leaves the page.
  var root = document.documentElement, TAB = /^#(summary|revisions|students)$/;
  var tabs = Array.prototype.slice.call(document.querySelectorAll("nav a"));
  function show(name) {
    root.setAttribute("data-tab", name);
    tabs.forEach(function (a) { a.classList.toggle("on", a.getAttribute("href") === "#" + name); });
  }
  var start = TAB.exec(location.hash);
  show(start ? start[1] : "summary");
  document.addEventListener("click", function (ev) {
    var a = ev.target.closest ? ev.target.closest("a[href]") : null;
    var m = a && TAB.exec(a.getAttribute("href"));
    if (!m) return;
    ev.preventDefault();
    show(m[1]);
    var card = document.getElementById(a.getAttribute("data-card") || "");
    if (card) {
      if (q && q.value) { q.value = ""; filter(); }
      card.open = true;
      card.scrollIntoView();
    } else {
      window.scrollTo(0, 0);
    }
  });
})();
"""
