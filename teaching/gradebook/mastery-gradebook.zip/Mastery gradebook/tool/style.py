"""Colours shared by the dashboard, the workbook and the phone page, so the three always match.

Each mark level gets a colour slot from LEVEL_SLOTS by its place in the list (see levels.SLOTS), so a
course with M, R and N gets green, amber and red. Those three were checked for colour-blind separation
as adjacent segments of a stacked bar, in light and dark mode. Table cells use light tints with dark
text, so the letter stays readable; the letter carries the meaning and the colour helps.
"""

from levels import HELD

INK, MUTED = "#0b0b0b", "#52514e"
HEADER = "#e1e0d9"

# bar: the stacked-bar colour and its text; tint: the light-mode cell; dark: the dark-mode cell and its text;
# badge: Streamlit's colour name for the student card.
LEVEL_SLOTS = [
    {"bar": "#076b07", "bar_text": "#ffffff", "tint": "#c2e4c2", "dark": ("#174a17", "#e4f6e4"), "badge": "green"},
    {"bar": "#0ca30c", "bar_text": "#ffffff", "tint": "#d3efd3", "dark": ("#1e5a1e", "#e4f6e4"), "badge": "green"},
    {"bar": "#8cc63f", "bar_text": "#0b0b0b", "tint": "#e6f3d4", "dark": ("#3f5a1c", "#eef7e2"), "badge": "green"},
    {"bar": "#fab219", "bar_text": "#0b0b0b", "tint": "#feecc0", "dark": ("#6b4d08", "#fff2d2"), "badge": "orange"},
    {"bar": "#ee7d2b", "bar_text": "#0b0b0b", "tint": "#fbe0d2", "dark": ("#6b3512", "#fde8da"), "badge": "orange"},
    {"bar": "#d03b3b", "bar_text": "#ffffff", "tint": "#f5d0d0", "dark": ("#6d2323", "#fde3e3"), "badge": "red"},
]
NOT_ATTEMPTED_COLOUR = "#a3a29b"
HELD_CELL = ("#ecf7ec", MUTED, 400)    # a standard already mastered at an earlier sitting
EMPTY_CELL = ("#f3f2ef", MUTED, 400)
GRADE_TINT = {"A": "#d3efd3", "B": "#d3efd3", "C": "#feecc0", "D": "#fbe0d2", "F": "#f5d0d0"}

# The teal of subhadipchowdhury.github.io, one step per mode so chart marks pass the readability checks.
ACCENT = {"light": "#04657d", "dark": "#2b9fb6"}


def cell(levels, mark):
    """Tint, text colour and weight of a table cell holding a mark."""
    if mark == HELD:
        return HELD_CELL
    slot = levels.slot(mark) if mark else None
    if slot is None:
        return EMPTY_CELL
    return LEVEL_SLOTS[slot]["tint"], INK, 600 if levels.mastered(mark) else 400


def status_colour(levels, status):
    """The bar colour of a level, or grey for not attempted."""
    slot = levels.slot(status)
    return NOT_ATTEMPTED_COLOUR if slot is None else LEVEL_SLOTS[slot]["bar"]


def badge(levels, mark):
    slot = levels.slot(mark)
    return "gray" if slot is None else LEVEL_SLOTS[slot]["badge"]


def excel(colour):
    """A colour in the form openpyxl wants, without the #."""
    return colour.lstrip("#").upper()
