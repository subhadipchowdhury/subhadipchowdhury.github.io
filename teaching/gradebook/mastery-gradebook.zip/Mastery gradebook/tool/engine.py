"""Mastery gradebook engine.

Reads a course folder (see files.py for its layout) and computes every table that the dashboard
and the Excel writer show. It reads the downloads in exports/ and never changes them. In records/
it keeps manual.csv (which gains rows for new students), office_hours.csv (the office-hour attempts,
which count as sittings), changes.csv (the marks that changed between two downloads of an export,
or in office_hours.csv) and last_seen.json (the marks at the last download).

Uses only the standard library and openpyxl, so the Excel build runs without Streamlit.
"""

from __future__ import annotations

import csv
import datetime as dt
import json
import re
import shutil
import statistics
from dataclasses import dataclass, field
from pathlib import Path

import canvas
from levels import HELD, NOT_ATTEMPTED, Levels  # noqa: F401  (HELD is used by the other modules)
from config import CONFIG_FILE, load_config, save_config  # noqa: F401  (save_config is used by the dashboard)
from files import (BACKUP_FILE, CHANGES_FILE, EXPORTS, MANUAL_FILE, OFFICE_BACKUP, OFFICE_FILE, OUTPUT, RECORDS,
                   SEEN_FILE, TOOL_FILES, classify, download_files, norm, output_dir, read_rows, records_dir, to_date,
                   to_float)


# Columns of a Gradescope export that are not questions.
EXPORT_META = {
    "first name", "last name", "sid", "email", "sections", "section", "total score",
    "max points", "status", "submission id", "submission time", "lateness (h:m:s)",
    "view count", "submission count",
}
QUESTION_PTS = re.compile(r"\s*\(\s*[\d.]+\s*pts?\s*\)\s*$")
REPEAT_DOWNLOAD = re.compile(r"\s*\(\d+\)$")  # " (1)" that a browser adds to a repeated download
CHANGE_COLUMNS = ["Export downloaded", "Noticed", "Sitting", "Student", "Email", "Standard", "From", "To"]
MANUAL_ID_COLUMNS = ["Email", "Last Name", "First Name"]
OFFICE_COLUMNS = ["Date", "Last Name", "First Name", "Email", "Standard", "Mark", "Kind", "Entered"]

write_canvas_upload = canvas.write_upload


def sitting_name(path: Path):
    stem = REPEAT_DOWNLOAD.sub("", path.stem)
    stem = re.sub(r"_scores$", "", stem, flags=re.IGNORECASE)
    return re.sub(r"[_\s]+", " ", stem).strip()


def sitting_label(name):
    parts = re.findall(r"[A-Za-z]+|\d+", name)
    return "".join(p if p.isdigit() else p[0].upper() for p in parts) or name


def change_text(row):
    """A row of changes.csv as "R → M"."""
    return f"{row['From']} → {row['To']}"


def day(d):
    """A date as "Nov 6"."""
    return f"{d:%b} {d.day}"


# ----------------------------------------------------------------------------- data

@dataclass
class Student:
    email: str
    last: str
    first: str
    sid: str = ""   # Gradescope's SID, which is Canvas's SIS User ID

    @property
    def name(self):
        return f"{self.first} {self.last}"


@dataclass
class Sitting:
    name: str
    label: str
    path: Path
    modified: dt.datetime
    date: dt.date | None = None
    standards: list = field(default_factory=list)
    marks: dict = field(default_factory=dict)    # email -> {standard: a level's name, or None}
    status: dict = field(default_factory=dict)   # email -> Gradescope status, e.g. "Graded"
    office: bool = False                         # True for the office-hour attempts between two sittings
    attempts: list = field(default_factory=list)  # for an office-hours sitting, its Attempt rows


@dataclass
class Attempt:
    """One office-hour attempt, a row of records/office_hours.csv."""
    row: int            # position in office_hours.csv, counting from 0 after the header
    date: dt.date
    email: str
    standard: str
    mark: str
    kind: str
    sitting: int = -1   # index in Gradebook.sittings


@dataclass
class FileInfo:
    path: Path
    kind: str
    modified: dt.datetime


class Gradebook:
    def __init__(self, folder, cfg):
        self.folder = Path(folder)
        self.cfg = cfg
        self.levels = Levels.from_config(cfg)
        self.students: list[Student] = []
        self.sittings: list[Sitting] = []
        self.standards: list[str] = []
        self.files: list[FileInfo] = []
        self.warnings: list[str] = []
        self.manual: dict = {}
        self.canvas: canvas.CanvasExport | None = None
        self.homework: dict = {}       # email -> homework score as a fraction, from the Canvas export
        self.changes: list = []        # every row of changes.csv
        self.new_changes: list = []    # the rows this load added
        self.loaded_at = dt.datetime.now()
        self.first_m: dict = {}   # (email, standard) -> index of the sitting where M was first earned
        self.best: dict = {}      # (email, standard) -> (mark, sitting index)
        self.office_on = False    # True when course.toml has [office_hours] or records/office_hours.csv exists
        self.office_rows: list = []   # every row of office_hours.csv, as read
        self.office: list = []        # the rows that could be read, as Attempts in date order

    # ------------------------------------------------------------------ basic lookups
    @property
    def title(self):
        c = self.cfg["course"]
        return ", ".join(x for x in (c.get("title", ""), c.get("term", "")) if x)

    @property
    def planned(self):
        return int(self.cfg["course"].get("planned_standards") or 0)

    @property
    def workbook_path(self):
        return self.folder / OUTPUT / self.cfg["course"].get("output", "Gradebook.xlsx")

    def describe(self, std):
        return self.cfg.get("standards", {}).get(std, "")

    def manual_columns(self):
        return [c["name"] for c in self.cfg.get("manual", [])]

    def manual_type(self, name):
        for c in self.cfg.get("manual", []):
            if c["name"] == name:
                return c.get("type", "text")
        return "text"

    # ------------------------------------------------------------------ marks and counts
    def mark(self, email, std):
        """Current status of a standard: the name of its best level, or None (never attempted)."""
        best = self.best.get((email, std))
        return best[0] if best else None

    def sitting_mark(self, email, k, std):
        """What sitting k shows: the mark given there, or HELD if the standard was mastered at an earlier
        sitting and the mark here is no better than the best one before."""
        mark = self.sittings[k].marks.get(email, {}).get(std)
        first = self.first_m.get((email, std))
        if first is not None and first < k:
            before = max(self.levels.rank(self.sittings[j].marks.get(email, {}).get(std)) for j in range(k))
            return mark if mark and self.levels.rank(mark) > before else HELD
        return mark

    def sitting_counts(self, k):
        """For each standard on sitting k, how many students show M, R, N, (M) and nothing (None)."""
        out = {}
        for std in self.sittings[k].standards:
            marks = [self.sitting_mark(s.email, k, std) for s in self.students]
            out[std] = {m: marks.count(m) for m in self.levels.names + [HELD, None]}
        return out

    def count_m(self, email, through=None):
        return sum(
            1 for std in self.standards
            if (k := self.first_m.get((email, std))) is not None and (through is None or k <= through)
        )

    def count_group(self, email, group):
        return sum(1 for std in self.cfg.get("groups", {}).get(group, []) if self.levels.mastered(self.mark(email, std)))

    def mastered_at(self, email, k):
        return [std for std in self.standards if self.first_m.get((email, std)) == k]

    def standard_counts(self, std, through=None):
        """Roster counts for one standard: one per level, and not attempted."""
        out = {k: 0 for k in self.levels.statuses}
        for s in self.students:
            if through is None:
                m = self.mark(s.email, std)
            else:
                marks = [self.sittings[k].marks.get(s.email, {}).get(std) for k in range(through + 1)]
                marks = [x for x in marks if x]
                m = max(marks, key=self.levels.rank) if marks else None
            out[m or NOT_ATTEMPTED] += 1
        return out

    def summary(self, through=None):
        counts = [self.count_m(s.email, through) for s in self.students]
        if not counts:
            return {"median": None, "mean": None, "q1": None, "q3": None}
        q1 = q3 = counts[0]
        if len(counts) > 1:
            q1, _, q3 = statistics.quantiles(counts, n=4, method="inclusive")
        return {"median": statistics.median(counts), "mean": statistics.fmean(counts), "q1": q1, "q3": q3}

    def pending_revisions(self):
        rows = []
        for s in self.students:
            for std in self.standards:
                best = self.best.get((s.email, std))
                if best and self.levels.revisable(best[0]):
                    rows.append((s, std, self.sittings[best[1]]))
        rows.sort(key=lambda r: (r[2].date or dt.date.max, r[0].last, r[0].first, r[1]))
        return rows

    def first_assessed(self, std):
        for sit in self.sittings:
            if std in sit.standards:
                return sit
        return None

    @property
    def assessed_count(self):
        return sum(1 for std in self.standards if self.first_assessed(std))

    def new_m_table(self):
        """For each sitting, how many students reached M on each standard there (None when the standard
        was not on that sitting), and the number mastered now, which is the sum of the rows."""
        rows = []
        for k, sit in enumerate(self.sittings):
            counts = {}
            for std in self.standards:
                if std in sit.standards:
                    counts[std] = sum(1 for s in self.students if self.first_m.get((s.email, std)) == k)
                else:
                    counts[std] = None
            rows.append((sit, counts))
        return rows, {std: sum(1 for s in self.students if self.levels.mastered(self.mark(s.email, std)))
                      for std in self.standards}

    # ------------------------------------------------------------------ office hours
    @property
    def office_kinds(self):
        return [k.get("name", "") for k in self.cfg.get("office_hours", {}).get("kind", []) if k.get("name")]

    def kind_settings(self, name):
        return next((k for k in self.cfg.get("office_hours", {}).get("kind", []) if k.get("name") == name), None)

    def _revised(self, a):
        """(sitting label, level) of the revisable mark that the office-hour attempt a fixes, or None. That
        is the last Gradescope sitting before the attempt, when it gave a revisable level on the attempt's
        standard, or gave one and changes.csv shows the mark changed later (an oral exam, or a fix entered
        on Gradescope too)."""
        graded = [k for k in range(a.sitting) if not self.sittings[k].office]
        if not graded:
            return None
        sit = self.sittings[graded[-1]]
        mark = sit.marks.get(a.email, {}).get(a.standard)
        if self.levels.revisable(mark):
            return sit.label, mark
        for r in self.changes:
            if (r.get("Sitting") == sit.label and (r.get("Email") or "").lower() == a.email
                    and r.get("Standard") == a.standard and self.levels.revisable(r.get("From"))):
                return sit.label, r["From"]
        return None

    def revises(self, a):
        """The label of the Gradescope sitting whose revisable mark the office-hour attempt a fixes, or None.
        Such an attempt is a revision and does not count toward the per-student limit of its kind."""
        fixed = self._revised(a)
        return fixed[0] if fixed else None

    def attempt_kind(self, a):
        """How an office-hour attempt counts, for display: "Fixes SA2 R" for a revision, else its kind."""
        fixed = self._revised(a)
        return f"Fixes {fixed[0]} {fixed[1]}" if fixed else a.kind

    def office_warnings(self):
        """The checks on the office-hour attempts. They read the manual entries as they are now, so a note
        typed in after the attempt was entered clears its warning at once."""
        out = []
        name = {s.email: s.name for s in self.students}
        by_kind = {}
        for a in self.office:
            if not self.revises(a):
                by_kind.setdefault((a.email, a.kind), []).append(a)
        for (email, kind), attempts in by_kind.items():
            ks = self.kind_settings(kind)
            limit = ks.get("per_student") if ks else None
            if limit is not None and len(attempts) > int(limit):
                listed = "; ".join(f"{a.standard} on {day(a.date)}" for a in attempts)
                out.append(f"Office hours: {name[email]} has {len(attempts)} attempts of the kind “{kind}”, "
                           f"and {limit} is allowed ({listed}).")
        for a in self.office:
            who, what = name[a.email], f"{a.standard} on {day(a.date)}"
            ks = self.kind_settings(a.kind)
            if ks is None:
                out.append(f"Office hours: {who}'s attempt at {what} has the kind “{a.kind}”, which course.toml "
                           "does not list.")
            else:
                ends = to_date(ks.get("before"))
                if ends and a.date >= ends:
                    out.append(f"Office hours: {who}'s attempt at {what} is of the kind “{a.kind}”, which has to "
                               f"be used before {day(ends)}.")
                column = ks.get("note_column")
                if column:
                    note = str(self.manual_value(a.email, column) or "").strip()
                    if not note:
                        out.append(f"Office hours: {who}'s attempt at {what} is of the kind “{a.kind}”, but the "
                                   f"{column} column is blank for {who}.")
                    elif a.standard not in re.findall(r"[^\s,;]+", note):
                        out.append(f"Office hours: {who}'s attempt at {what} is of the kind “{a.kind}”, but the "
                                   f"{column} column gives {note}.")
            first = self.first_m.get((a.email, a.standard))
            if first is not None and first < a.sitting:
                out.append(f"Office hours: {who} attempted {what}, but {a.standard} was already {self.levels.at} from "
                           f"{self.sittings[first].label}.")
            elif any(b.email == a.email and b.standard == a.standard and self.levels.mastered(b.mark)
                     and (b.date, b.row) < (a.date, a.row) for b in self.sittings[a.sitting].attempts):
                out.append(f"Office hours: {who} attempted {what}, but {a.standard} was already {self.levels.at} from an "
                           "earlier office-hour attempt.")
        return out

    def all_warnings(self):
        return self.warnings + self.office_warnings()

    # ------------------------------------------------------------------ manual entries and grades
    def manual_value(self, email, column):
        raw = (self.manual.get(email, {}).get(column) or "").strip()
        kind = self.manual_type(column)
        if not raw:
            return None
        if kind == "percent":
            x = to_float(raw.rstrip("%"))
            if x is None:
                return None
            return x / 100 if x > 1 else x
        if kind == "integer":
            x = to_float(raw)
            return int(x) if x is not None else None
        if kind == "yes/no":
            return raw.lower() in {"yes", "y", "true", "1", "x"}
        return raw

    def homework_score(self, email):
        """The homework score as a fraction: from the Canvas export if there is one, otherwise
        from the manual column named in course.toml."""
        if self.canvas is not None:
            return self.homework.get(email)
        column = self.cfg.get("grading", {}).get("homework_column", "")
        return self.manual_value(email, column) if column in self.manual_columns() else None

    def base_grade(self, email):
        """The first row of the grade table whose requirements are all met, or "F" if none is.
        None until every planned standard has been assessed, since before that the checklist
        gives an F to everyone, and None while the homework score is missing."""
        rows = self.cfg.get("grade", [])
        if not rows or (self.planned and self.assessed_count < self.planned):
            return None
        homework = self.homework_score(email)
        total = self.count_m(email)
        for row in rows:
            met = True
            for key, need in row.items():
                if key == "letter":
                    continue
                if key == "standards":
                    ok = total >= need
                elif key == "homework":
                    if homework is None:
                        return None
                    ok = homework >= need - 1e-9
                else:
                    ok = self.count_group(email, key) >= need
                met = met and ok
            if met:
                return row["letter"]
        return "F"


# ----------------------------------------------------------------------------- Gradescope and roster

def _decode(value, levels):
    x = to_float(value)
    if x is None:
        return None, False
    return levels.decode(x)


def _read_export(path, gb: Gradebook, by_email, by_name):
    rows = read_rows(path)
    header = rows[0]
    col = {norm(h): i for i, h in enumerate(header)}
    g = gb.cfg["gradescope"]
    pattern = re.compile(g.get("standard_pattern", r"S\d+"))
    name = sitting_name(path)
    sit = Sitting(name=name, label=gb.cfg.get("sittings", {}).get(name, sitting_label(name)), path=path,
                  modified=dt.datetime.fromtimestamp(path.stat().st_mtime))

    questions = []  # (column index, standard)
    for i, h in enumerate(header):
        if norm(h) in EXPORT_META or h is None:
            continue
        found = pattern.search(QUESTION_PTS.sub("", str(h)))
        if not found:
            gb.warnings.append(f"{sit.label}: column “{h}” has no standard in its title, so it is ignored.")
            continue
        std = found.group(0)
        if std in (q[1] for q in questions):
            gb.warnings.append(f"{sit.label}: {std} appears in more than one question; only the first is used.")
            continue
        questions.append((i, std))
    sit.standards = [std for _, std in questions]

    dates, unmatched, odd, totals_off, ungraded = [], [], [], [], 0
    for r in rows[1:]:
        email = str(r[col["email"]] or "").strip().lower()
        first, last = str(r[col["first name"]] or "").strip(), str(r[col["last name"]] or "").strip()
        if not email and not first and not last:
            continue
        student = by_email.get(email)
        if student is None:
            student = by_name.get((first.lower(), last.lower()))
            if student is not None:
                gb.warnings.append(f"{sit.label}: {first} {last} matched to the roster by name, since the email "
                                   f"{email} is not on the roster.")
            else:
                unmatched.append(f"{first} {last} ({email})")
                continue
        status = str(r[col["status"]] or "").strip() if "status" in col else ""
        sit.status[student.email] = status
        if "sid" in col and r[col["sid"]]:
            student.sid = str(r[col["sid"]]).strip()
        if status.lower() == "ungraded":
            ungraded += 1
        marks, raw_sum = {}, 0.0
        for i, std in questions:
            mark, unexpected = _decode(r[i], gb.levels)
            if unexpected:
                odd.append(f"{student.name} {std} = {r[i]}")
            marks[std] = mark
            raw_sum += to_float(r[i]) or 0.0
        sit.marks[student.email] = marks
        total = to_float(r[col["total score"]]) if "total score" in col else None
        if total is not None and abs(total - raw_sum) > 1e-6:
            totals_off.append(student.name)
        if "submission time" in col and any(marks.values()):
            d = to_date(r[col["submission time"]])
            if d:
                dates.append(d)
    sit.date = min(dates) if dates else None

    if unmatched:
        gb.warnings.append(f"{sit.label}: not on the roster, so left out: " + "; ".join(unmatched) + ".")
    if odd:
        gb.warnings.append(f"{sit.label}: scores that are not the score of a level, treated as not attempted: "
                           + "; ".join(odd) + ".")
    if totals_off:
        gb.warnings.append(f"{sit.label}: Total Score differs from the sum of the question scores for "
                           + ", ".join(totals_off) + ". A question column may be missing from the export.")
    if ungraded:
        gb.warnings.append(f"{sit.label}: {ungraded} submission(s) not graded yet.")
    absent = [s.name for s in gb.students if s.email not in sit.status]
    if absent:
        gb.warnings.append(f"{sit.label}: on the roster but not in the export: " + ", ".join(absent) + ".")
    return sit


def scan_exports(folder, pattern):
    """For the setup page: the Gradescope exports in the folder, each as (file name, the standards the
    pattern finds in its question titles, the titles it finds none in), and every distinct score in their
    question columns. A pattern that is not a valid regular expression finds nothing."""
    try:
        rx = re.compile(pattern)
    except re.error:
        rx = None
    found, scores = [], set()
    for path, _ in download_files(folder, ""):
        try:
            rows = read_rows(path)
        except Exception:  # a file still syncing, or open in another program
            continue
        if not rows or classify(rows[0]) != "export":
            continue
        stds, missed, cols = [], [], []
        for i, h in enumerate(rows[0]):
            if h is None or norm(h) in EXPORT_META:
                continue
            cols.append(i)
            m = rx.search(QUESTION_PTS.sub("", str(h))) if rx else None
            if m:
                stds.append(m.group(0))
            else:
                missed.append(str(h))
        for r in rows[1:]:
            for i in cols:
                x = to_float(r[i])
                if x is not None:
                    scores.add(round(x, 6))
        found.append((path.name, stds, missed))
    return found, sorted(scores, reverse=True)


def _read_roster(path):
    rows = read_rows(path)
    col = {norm(h): i for i, h in enumerate(rows[0])}
    students = []
    for r in rows[1:]:
        email = str(r[col["email"]] or "").strip().lower()
        if email:
            students.append(Student(email=email, last=str(r[col["lastname"]] or "").strip(),
                                    first=str(r[col["firstname"]] or "").strip()))
    students.sort(key=lambda s: (s.last.lower(), s.first.lower()))
    return students


# ----------------------------------------------------------------------------- records

def _manual_path(folder):
    return records_dir(folder) / MANUAL_FILE


def _read_manual_file(path):
    """manual.csv as (columns, rows); ([], []) if it does not exist yet."""
    if not path.exists():
        return [], []
    with open(path, newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        return list(reader.fieldnames or []), list(reader)


def _write_manual_file(path, columns, rows):
    with open(path, "w", newline="", encoding="utf-8-sig") as fh:
        writer = csv.DictWriter(fh, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for r in rows:
            writer.writerow({c: r.get(c, "") or "" for c in columns})


def _by_email(rows):
    return {(r.get("Email") or "").strip().lower(): r for r in rows}


def _load_manual(gb: Gradebook):
    """Read manual.csv, adding rows for new roster students and any new columns."""
    path = _manual_path(gb.folder)
    existing, rows = _read_manual_file(path)
    columns = MANUAL_ID_COLUMNS + gb.manual_columns()
    known = set(_by_email(rows))
    changed = not path.exists() or any(c not in existing for c in columns)
    for s in gb.students:
        if s.email not in known:
            rows.append({"Email": s.email, "Last Name": s.last, "First Name": s.first})
            changed = True
    if changed:
        _write_manual_file(path, columns + [c for c in existing if c not in columns], rows)
    gb.manual = _by_email(rows)


def read_manual(folder: Path):
    """manual.csv as {email: row}, read afresh."""
    return _by_email(_read_manual_file(_manual_path(folder))[1])


def save_manual(gb: Gradebook, edited):
    """Write edited manual entries ({email: {column: value}}) into manual.csv, changing only those
    cells. Before the first change of each day, the file is copied to manual.backup.csv."""
    path = _manual_path(gb.folder)
    backup = path.with_name(BACKUP_FILE)
    if not backup.exists() or dt.date.fromtimestamp(backup.stat().st_mtime) < dt.date.today():
        shutil.copy(path, backup)  # copy, not copy2, so the backup's date is today's
    columns, rows = _read_manual_file(path)
    columns += [c for c in MANUAL_ID_COLUMNS + gb.manual_columns() if c not in columns]
    for r in rows:
        email = (r.get("Email") or "").strip().lower()
        for c, v in edited.get(email, {}).items():
            r[c] = "" if v is None else str(v)
    _write_manual_file(path, columns, rows)


def _office_path(folder):
    return Path(folder) / RECORDS / OFFICE_FILE


def read_office_rows(folder: Path):
    """Every row of office_hours.csv, as dicts; [] if the file does not exist yet."""
    return _read_manual_file(_office_path(folder))[1]


def _write_office_rows(folder: Path, rows):
    """Write office_hours.csv. Before the first change of each day, the file is copied to
    office_hours.backup.csv."""
    path = records_dir(folder) / OFFICE_FILE
    if path.exists():
        backup = path.with_name(OFFICE_BACKUP)
        if not backup.exists() or dt.date.fromtimestamp(backup.stat().st_mtime) < dt.date.today():
            shutil.copy(path, backup)
    columns, _ = _read_manual_file(path)
    _write_manual_file(path, OFFICE_COLUMNS + [c for c in columns if c not in OFFICE_COLUMNS], rows)


def add_office_attempt(gb: Gradebook, date, email, standard, mark, kind):
    """Add one office-hour attempt to office_hours.csv."""
    s = next(x for x in gb.students if x.email == email)
    rows = read_office_rows(gb.folder)
    rows.append({"Date": to_date(date).isoformat(), "Last Name": s.last, "First Name": s.first, "Email": email,
                 "Standard": standard, "Mark": mark, "Kind": kind,
                 "Entered": dt.datetime.now().strftime("%Y-%m-%d %H:%M")})
    _write_office_rows(gb.folder, rows)


def save_office_edits(folder: Path, edited, deleted=()):
    """Change cells of office_hours.csv ({row: {column: value}}) and delete rows, where a row is its
    position in the file as last read."""
    rows = read_office_rows(folder)
    for i, changes in edited.items():
        for column, value in changes.items():
            if column == "Date" and to_date(value):
                value = to_date(value).isoformat()
            rows[int(i)][column] = "" if value is None else str(value)
    gone = {int(i) for i in deleted}
    _write_office_rows(folder, [r for i, r in enumerate(rows) if i not in gone])


def _add_office_sittings(gb: Gradebook, by_email):
    """Read office_hours.csv and put its attempts into gb.sittings. The attempts dated between two
    Gradescope sittings form one sitting, placed between them."""
    path = _office_path(gb.folder)
    gb.office_rows = read_office_rows(gb.folder)
    attempts = []
    for i, r in enumerate(gb.office_rows):
        email = (r.get("Email") or "").strip().lower()
        date = to_date(r.get("Date"))
        std = (r.get("Standard") or "").strip()
        mark = gb.levels.canonical(r.get("Mark")) or (r.get("Mark") or "").strip()
        who = f"{r.get('First Name') or ''} {r.get('Last Name') or ''}".strip() or email or "no name"
        if not email:
            problem = "the email is blank"
        elif email not in by_email:
            problem = f"{email} is not on the roster"
        elif date is None:
            problem = "the date is missing or not a date"
        elif std not in gb.standards:
            problem = f"“{std}” is not a standard of the course"
        elif not gb.levels.rank(mark):
            problem = f"the mark “{mark}” is not one of the levels {', '.join(gb.levels.names)}"
        else:
            attempts.append(Attempt(i, date, email, std, mark, (r.get("Kind") or "").strip()))
            continue
        gb.warnings.append(f"Office hours: in row {i + 2} of {OFFICE_FILE} ({who}), {problem}, so the row is "
                           "left out.")
    attempts.sort(key=lambda a: (a.date, a.row))
    gb.office = attempts
    if not attempts:
        return

    graded = list(gb.sittings)
    groups = {}   # index in graded of the sitting before the attempt, or -1 -> its attempts
    for a in attempts:
        before = [k for k, s in enumerate(graded) if s.date and s.date <= a.date]
        groups.setdefault(before[-1] if before else -1, []).append(a)
    label = str(gb.cfg.get("office_hours", {}).get("label") or "OH")
    modified = dt.datetime.fromtimestamp(path.stat().st_mtime)
    office = {}
    for key, group in groups.items():
        prev = graded[key] if key >= 0 else None
        sit = Sitting(name=f"Office hours after {prev.name}" if prev else "Office hours",
                      label=label if len(groups) == 1 or prev is None else f"{label} after {prev.label}",
                      path=path, modified=modified, date=group[0].date, office=True, attempts=group)
        sit.standards = [std for std in gb.standards if any(a.standard == std for a in group)]
        for a in group:
            marks = sit.marks.setdefault(a.email, {})
            if marks.get(a.standard) is None or gb.levels.rank(a.mark) > gb.levels.rank(marks[a.standard]):
                marks[a.standard] = a.mark
            sit.status[a.email] = "Attempted"
        office[key] = sit
    gb.sittings = ([office[-1]] if -1 in office else [])
    for k, sit in enumerate(graded):
        gb.sittings += [sit] + ([office[k]] if k in office else [])
    for k, sit in enumerate(gb.sittings):
        for a in sit.attempts:
            a.sitting = k


def _track_changes(gb: Gradebook):
    """Compare each sitting with the marks seen at its last download, and record the differences
    in changes.csv. A sitting seen for the first time is only remembered."""
    rec = records_dir(gb.folder)
    seen_path, log_path = rec / SEEN_FILE, rec / CHANGES_FILE
    seen = json.loads(seen_path.read_text(encoding="utf-8")) if seen_path.exists() else {}
    by_email = {s.email: s for s in gb.students}
    now = dt.datetime.now().strftime("%Y-%m-%d %H:%M")
    new_rows, updated = [], dict(seen)
    for sit in gb.sittings:
        current = {e: {std: (m or "") for std, m in marks.items()} for e, marks in sit.marks.items()}
        before = seen.get(sit.name)
        if before is not None:
            for email in sorted(set(before) | set(current)):
                stds = sit.standards
                if sit.office:  # a deleted attempt can take its standard off the sitting
                    stds = sorted({std for m in (before, current) for marks in m.values() for std in marks})
                for std in stds:
                    old = before.get(email, {}).get(std, "")
                    new = current.get(email, {}).get(std, "")
                    if sit.office and not old:
                        continue  # a new office-hour attempt is in office_hours.csv, not a change of mark
                    if old != new and email in by_email:
                        new_rows.append({"Export downloaded": f"{sit.modified:%Y-%m-%d %H:%M}", "Noticed": now,
                                         "Sitting": sit.label, "Student": by_email[email].name, "Email": email,
                                         "Standard": std, "From": old or "blank", "To": new or "blank"})
        updated[sit.name] = current
    if new_rows:
        new_file = not log_path.exists()
        with open(log_path, "a", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=CHANGE_COLUMNS)
            if new_file:
                writer.writeheader()
            writer.writerows(new_rows)
    if updated != seen:
        seen_path.write_text(json.dumps(updated, indent=1, sort_keys=True), encoding="utf-8")
    gb.new_changes = new_rows
    if log_path.exists():
        with open(log_path, newline="", encoding="utf-8") as fh:
            gb.changes = list(csv.DictReader(fh))


# ----------------------------------------------------------------------------- loading

def source_files(folder: Path):
    """The files the gradebook is built from: course.toml, the downloads and the office-hour attempts.
    Writing the other records or the output does not change this list."""
    folder = Path(folder)
    cfg = load_config(folder)
    paths = [p for p, _ in download_files(folder, cfg["course"].get("output", ""))]
    config, office = folder / CONFIG_FILE, _office_path(folder)
    return ([config] if config.exists() else []) + paths + ([office] if office.exists() else [])


def load(folder):
    """Build the gradebook from everything in the folder."""
    folder = Path(folder).resolve()
    cfg = load_config(folder)
    gb = Gradebook(folder, cfg)
    if not gb.levels.ok:
        gb.warnings.append("The mark levels cannot be used, so no marks are read: " + " ".join(gb.levels.problems)
                           + " Set them on the Setup tab of the dashboard.")
    workbook = cfg["course"].get("output", "")

    for name in sorted(TOOL_FILES | {workbook.lower(), SEEN_FILE}):
        if any(p.name.lower() == name for p in folder.iterdir()):
            gb.warnings.append(f"{name} is in the main folder. The tool keeps its own files in records/ and "
                               "output/, so this copy is not used.")

    rosters, exports, canvases = [], [], []
    for path, at_top in download_files(folder, workbook):
        modified = dt.datetime.fromtimestamp(path.stat().st_mtime)
        try:
            rows = read_rows(path)
        except Exception as exc:  # a file still syncing, or open in another program
            gb.warnings.append(f"Could not read {path.name}: {exc}")
            continue
        kind = classify(rows[0]) if rows else None
        gb.files.append(FileInfo(path, kind or "not recognised", modified))
        if kind and at_top:
            gb.warnings.append(f"{path.name} is in the main folder. It was read, but downloads belong in {EXPORTS}/.")
        {"roster": rosters, "export": exports, "canvas": canvases}.get(kind, []).append(path)

    if not rosters:
        gb.warnings.append(f"No roster found. Put the registrar's class list (a CSV with LastName, FirstName and "
                           f"Email) in {EXPORTS}/.")
    else:
        rosters.sort(key=lambda p: p.stat().st_mtime)
        if len(rosters) > 1:
            gb.warnings.append(f"Several rosters found; using the newest, {rosters[-1].name}.")
        gb.students = _read_roster(rosters[-1])
    by_email = {s.email: s for s in gb.students}
    by_name = {(s.first.lower(), s.last.lower()): s for s in gb.students}

    # One export per sitting. A repeated download such as "..._scores (1).xlsx" replaces the older file.
    newest = {}
    for path in exports:
        name = sitting_name(path)
        if name in newest:
            older, newer = sorted([newest[name], path], key=lambda p: p.stat().st_mtime)
            gb.warnings.append(f"Two exports of {name}: using {newer.name}, the newer, and ignoring {older.name}.")
            newest[name] = newer
        else:
            newest[name] = path
    gb.sittings = [_read_export(path, gb, by_email, by_name) for path in newest.values()]

    def order(sit):
        num = re.findall(r"\d+", sit.name)
        return (sit.date or dt.date.max, int(num[-1]) if num else 0, sit.name)
    gb.sittings.sort(key=order)
    labels = [s.label for s in gb.sittings]
    for sit in gb.sittings:
        if labels.count(sit.label) > 1:
            sit.label = sit.name

    # Standards: those listed in course.toml, then any others in the order the sittings introduce them.
    stds = list(cfg.get("standards", {}).keys())
    for sit in gb.sittings:
        stds += [s for s in sit.standards if s not in stds]
    unlisted = [s for s in stds if s not in cfg.get("standards", {})]
    if unlisted and cfg.get("standards"):
        gb.warnings.append("Standards in the exports but not in course.toml: " + ", ".join(unlisted) + ".")
    gb.standards = stds
    if gb.planned and len(stds) > gb.planned:
        gb.warnings.append(f"{len(stds)} standards exist but course.toml plans {gb.planned}.")
    for row in cfg.get("grade", []):
        need = row.get("standards")
        if gb.planned and need and need > gb.planned:
            gb.warnings.append(f"Grade {row.get('letter')} asks for {need} standards, more than the {gb.planned} planned.")
        for key in row:
            if key not in {"letter", "standards", "homework"} and key not in cfg.get("groups", {}):
                gb.warnings.append(f"Grade {row.get('letter')}: “{key}” is not a group in course.toml.")

    gb.office_on = bool(cfg.get("office_hours")) or _office_path(folder).exists()
    if gb.office_on:
        _add_office_sittings(gb, by_email)

    for k, sit in enumerate(gb.sittings):
        for email, marks in sit.marks.items():
            for std, mark in marks.items():
                if not mark:
                    continue
                prev = gb.best.get((email, std))
                # >= so that an R given again at a later sitting is listed at that sitting on Revisions
                if prev is None or gb.levels.rank(mark) >= gb.levels.rank(prev[0]):
                    gb.best[(email, std)] = (mark, k)
                if gb.levels.mastered(mark) and (email, std) not in gb.first_m:
                    gb.first_m[(email, std)] = k

    _load_manual(gb)
    if canvases:
        canvases.sort(key=lambda p: p.stat().st_mtime)
        assessed = [std for std in gb.standards if gb.first_assessed(std)]
        gb.canvas, gb.homework, warnings = canvas.read_canvas(canvases[-1], cfg, gb.students, assessed)
        gb.warnings += warnings
    _track_changes(gb)
    output_dir(folder)
    return gb
