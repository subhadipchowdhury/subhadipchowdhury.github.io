#!/bin/bash
# Finds a Python 3.11 or later, checks the packages the gradebook needs, and runs it.
# The .command launchers in the course folder call it:  bash tool/launch.sh dashboard  (or build).
# If no suitable Python is found, it offers to download the python.org installer and open it.
cd "$(dirname "$0")/.." || exit 1
export PYTHONDONTWRITEBYTECODE=1
PY_VERSION=3.13.17   # the version the python.org installer downloads; the gradebook was tested with 3.13
PY_PKG="https://www.python.org/ftp/python/$PY_VERSION/python-$PY_VERSION-macos11.pkg"

pause() { echo; read -n 1 -s -r -p "Press any key to close this window."; echo; }

good() { [ -n "$1" ] && [ -x "$1" ] && "$1" -c 'import sys; sys.exit(sys.version_info < (3, 11))' 2>/dev/null; }

# Homebrew's Python (the office Mac), then the python.org installs, then whatever python3 the PATH gives.
# A Terminal in a conda environment puts conda's python3 first on the PATH, so it comes last here.
PY=""
for p in /opt/homebrew/opt/python@3.13/libexec/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.13/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.14/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.12/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.11/bin/python3 \
         /opt/homebrew/bin/python3 /usr/local/bin/python3 "$(command -v python3)"; do
    if good "$p"; then PY="$p"; break; fi
done

if [ -z "$PY" ]; then
    echo "The gradebook needs Python 3.11 or later, and this computer does not have it."
    echo
    read -r -p "Download the Python $PY_VERSION installer from python.org and open it now? [y/N] " answer
    if [[ "$answer" =~ ^[Yy] ]]; then
        pkg="${TMPDIR:-/tmp}/python-$PY_VERSION-macos11.pkg"
        echo "Downloading $PY_PKG"
        if curl -fL --progress-bar -o "$pkg" "$PY_PKG"; then
            open "$pkg"
            echo
            echo "The installer is open. Follow its steps (it asks for this computer's password),"
            echo "then open this launcher again."
        else
            echo "The download failed. Install Python from https://www.python.org/downloads/ and open this launcher again."
        fi
    else
        echo "Install Python from https://www.python.org/downloads/ and open this launcher again."
    fi
    pause
    exit 1
fi

case "$1" in
    dashboard)
        if ! "$PY" tool/check_setup.py --dashboard; then pause; exit 1; fi
        # Colours and the toolbar are set in .streamlit/config.toml; the two privacy settings are repeated here.
        "$PY" -m streamlit run tool/dashboard.py --server.address localhost --browser.gatherUsageStats false
        ;;
    build)
        if "$PY" tool/check_setup.py; then "$PY" tool/build.py; fi
        pause
        ;;
    *)
        echo "Usage: bash tool/launch.sh dashboard|build"
        exit 2
        ;;
esac
